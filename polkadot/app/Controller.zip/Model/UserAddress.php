<?php
class UserAddress extends AppModel
{

	// Cardinality mapping
	var $belongsTo = array('User');
}
?>