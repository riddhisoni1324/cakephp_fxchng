<?php
class OrderItem extends AppModel
{

	// Cardinality mapping
	var $belongsTo = array('Order','Item','OrderDispatch');
}
?>