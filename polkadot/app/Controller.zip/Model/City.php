<?php
class City extends AppModel
{

	// Cardinality mapping
    var $belongsTo = array('State');
}
?>