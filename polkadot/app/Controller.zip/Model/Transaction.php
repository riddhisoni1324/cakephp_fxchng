<?php
class Transaction extends AppModel
{

}
?>