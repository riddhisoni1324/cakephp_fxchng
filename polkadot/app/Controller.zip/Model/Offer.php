<?php
class Offer extends AppModel
{
    // Configuration for image upload
    public $actsAs = array(
        'Upload.Upload' => array(

            // Field in the table which will store the path of the image
            'offer_filename' => array(

                // Allowed mime types
                'mimetypes'=> array('image/jpg','image/jpeg', 'image/png'),

                // Use php for localhost or where imagick is not installed
                'thumbnailMethod'=>"php",

                // Allowed set of extensions
                'extensions'=> array('jpg','png','JPG','PNG','jpeg','JPEG'),

                // Specify the thumbnail sizes
                'thumbnailSizes' => array(
                    'offer' => '250x250',
                    'thumb' => '100x100'
                ),

                // Map the directory path to specified field in the table
                'fields' => array(
                    'dir' => 'file_dir'
                )
            )
        )
    );

}
?>
