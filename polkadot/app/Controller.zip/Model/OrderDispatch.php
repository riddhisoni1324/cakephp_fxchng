<?php
class OrderDispatch extends AppModel
{
	
	// Cardinality mappings
    var $hasMany = array('OrderItem');
    var $belongsTo = array('Order','Courier');

}
?>