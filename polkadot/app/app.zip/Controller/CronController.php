<?php

App::uses('CakeTime', 'Utility');
App::uses('CakeEmail', 'Network/Email');
class CronController extends AppController {

	/*public function beforeFilter() {
	    parent::beforeFilter();
		$this->Auth->allow('incomplete_payment_cron','admin_reset_cron');
	    $this->layout=null;
	}

	public $uses = array('Order', 'OrderItem','User', 'Courier', 'OrderDispatch','City','State','Coupon','Admin');
	
	//This sends email to incomplete payment distinct users
	public function incomplete_payment_cron() {
		// Check the action is being invoked by the cron dispatcher 
		if (!defined('CRON_DISPATCHER')) { $this->redirect('/'); exit(); } 

		//no view
		$this->autoRender = false;

		$this->OrderItem->Behaviors->load('Containable');
		$orders = $this -> OrderItem -> find('all',
		array('conditions' => array('Order.status' => 0,
		array('OrderItem.order_dispatch_id'=>null),
		array('NOT'=>array('Order.user_id'=>null))),
		'contain' => array('Order','Order.User'),
		'fields' => array('DISTINCT Order.user_id')
		));
		
		foreach($orders as $order){
			//use this as per requirements
			$user = $this -> User -> findById($order['Order']['user_id']);
			$first_name = $user['User']['first_name'];
			$last_name = $user['User']['last_name'];
			$username = $user['User']['username'];
			$mobile = $user['User']['mobile'];
			
			$userEmail = "ishan.sheth@actonate.com";
			$subject = "Hello";
			$message = "Hey, ".$first_name." !<br/>";
			$message .= "You have pending order/s with us at cakestudio.";
			
			$Email = new CakeEmail('default');
			$Email->config('default');
			$Email->emailFormat("html");
			$Email->template('default');
			$Email -> to($userEmail);
			$Email -> subject($subject);
			$Email -> send($message);
		}
		return;
	}	
	
	//This sends email to polka admins after resetting their password to random string
	public function admin_reset_cron() {
		// Check the action is being invoked by the cron dispatcher 
		if (!defined('CRON_DISPATCHER')) { $this->redirect('/'); exit(); } 

		//no view
		$this->autoRender = false;

		$length = 15;
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ@#$+=-';
		
		
		$admins = $this -> Admin -> find('all');
		
		foreach($admins as $admin){
		
			$randomString = '';
			for ($i = 0; $i < $length; $i++) {
				$randomString .= $characters[rand(0, strlen($characters) - 1)];
			}
			$randomString;
			
			$admin['Admin']['password'] = $randomString;
			
			if ($this->Admin ->save($admin)) {
				$subject = "[Polkadot Security Agent] Your polkadot access password has been reset";
				$message = "Hey, ".$admin['Admin']['name']." !<br/><br/>";
				$message .= "Your polkadot access password has been reset, details are as follows :<br/><br/>";
				$message .= "Username : ".$admin['Admin']['username']."<br/>";
				$message .= "Password : ".$randomString."<br/>";
				
				$Email = new CakeEmail('default');
				$Email->config('default');
				$Email->emailFormat("html");
				$Email->template('default');
				$Email -> to(array('ishan.sheth@actonate.com','shoaib@actonate.com','pratik@actonate.com','rohit@cakestudio.in'));
				//$Email -> to(array('ishan.sheth@actonate.com'));
				$Email -> subject($subject);
				$Email -> send($message);				
			}
		}

		return;
	}*/
	
}
?>