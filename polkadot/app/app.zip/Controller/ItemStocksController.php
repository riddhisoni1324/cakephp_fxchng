<?php
class ItemStocksController extends AppController {

	public $name = 'ItemStocks';
	public $uses = array('ItemStock','Item','ItemType','City','ItemStockCity','Vendor');




    
    /*
    // Objective : This function displays all the item stocks
    // Author : Ishan Sheth
    // Last Edit : 10/8/2014
    */
	public function index() {

        // Check whether it is a post request
        if ($this -> request -> is('post')) {

            // Redirect to add item for supplied item id in the post request
            $selectedItem = $this->request->data;
            $this -> redirect(array('controller' => 'item_stocks', 'action' => 'add', $selectedItem['ItemStock']['selected_item']));

        } else {

            // we prepare our query, the cakephp way!
            $this->paginate = array(
                'limit' => 10,
                'order' => array('ItemStock.modified' => 'desc'),
            );
         
            // we are using the 'ItemStock' model
            $itemStocks = $this->paginate('ItemStock'); 
                       
            $this -> set('item_stocks', $itemStocks);
        }

        $item_count = $this-> ItemStock ->find('all');
        $item_count1 = sizeof($item_count);
        $this->set('item_count',$item_count1);

        // Set the view variables to controller variable values and layout for the view
		$this -> set('page_title', 'View Item Stocks');
		$this -> layout = 'base_layout';

	}




    
    /*
    // Objective : This function adds the item stock
    // Author : Ishan Sheth
    // Last Edit : 10/8/2014
    */
	public function add($id=null) {

        // Check whether it is a post request or not
		if ($this -> request -> is('post')) {

            // Get the data from post request
			$itemStock = $this -> request -> data;

            // Sanity check or redirect
            if($itemStock['ItemStock']['price'] < $itemStock['ItemStock']['discount_price'] ) {

                // Display error message and redirect
                $this->Session->setFlash('Discount price cannot be greater than price.', 'default', array('class' => 'alert alert-success') , 'success');
                $this -> redirect($this->referer());

            }

            // Calculate discount percent from item price and discounted price
            if(!empty($itemStock['ItemStock']['discount_price'])) {

                // Calculate discount percent if discount price is not empty
                $discount_percent = round(($itemStock['ItemStock']['price'] - $itemStock['ItemStock']['discount_price'])/$itemStock['ItemStock']['price'],2)*100;

            } else {

                // Calculate discount percent to 0 if discount price is empty
                $itemStock['ItemStock']['discount_price'] = $itemStock['ItemStock']['price'];
                $discount_percent = 0;

            }

            // Set discount percent
            $itemStock['ItemStock']['discount_percentage'] = $discount_percent;

            // Add stock
            if ($this -> ItemStock -> save($itemStock)) {

                // Display success message and redirect
                $this->Session->setFlash('New stock added.', 'default', array('class' => 'alert alert-success') , 'success');
                $this -> redirect(array('controller' => 'item_stocks', 'action' => 'index'));

			} else {

				// Display failure message and redirect
                $this->Session->setFlash('Sorry an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'item_stocks', 'action' => 'index'));
			}

		} else {

            // Check whether ID is null, if yes - redirect to index
            if($id == null){
                $this->Session->setFlash('No item selected.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'item_stocks', 'action' => 'index'));
            }

            // Fetch the item by id
            $selectedItem = $this->Item->findById($id);

            // Check whether resultset is null, if yes - redirect to index
            if($selectedItem == null){

                // Display failure message and redirect
                $this->Session->setFlash('No item selected.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'item_stocks', 'action' => 'index'));

            } elseif ($selectedItem['Item']['stock_type'] == 1) {

                // Display failure message and redirect, if stock type of item selected is set to infinite
                $this->Session->setFlash('Stock for item is set to infinite.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'item_stocks', 'action' => 'index'));
            }

            // Get vendors
            $vendors = $this -> Vendor -> find('list', array('conditions'=>array('Vendor.id NOT'=>'53e9c4b2-6c28-4a73-a8c3-3519bf642048'),'order' => 'Vendor.name ASC'));
            $this -> set('vendors', $vendors);

            // Set the view variables to controller variable values and layout for the view
            $this->set('selectedItem',$selectedItem);
            $this -> set('page_title', 'Add Item Stock');
            $this -> layout = 'base_layout';
		}
	}




    
    /*
    // Objective : This function saves the edited item stock
    // Author : Ishan Sheth
    // Last Edit : 8/8/2014
    */
    public function edit($id=null) {

        // Check whether it is a post request or not
        if ($this -> request -> is('post')) {

            // Get the data from post request
            $itemStock = $this -> request -> data;

            // Sanity check or redirect
            if($itemStock['ItemStock']['price'] < $itemStock['ItemStock']['discount_price'] ) {

                // Display error message and redirect
                $this->Session->setFlash('Discount price cannot be greater than price.', 'default', array('class' => 'alert alert-success') , 'success');
                $this -> redirect($this->referer());

            }            

            // Calculate discount percent from item price and discounted price            
            if(!empty($itemStock['ItemStock']['discount_price']))
            {

                // Calculate discount percent if discount price is not empty
                $discount_percent = round(($itemStock['ItemStock']['price'] - $itemStock['ItemStock']['discount_price'])/$itemStock['ItemStock']['price'],2)*100;

            } else {

                // Calculate discount percent to 0 if discount price is empty
                $itemStock['ItemStock']['discount_price'] = $itemStock['ItemStock']['price'];
                $discount_percent = 0;
            }

            // Set discount percent
            $itemStock['ItemStock']['discount_percentage'] = $discount_percent;

            // Save item stock
            if ($this -> ItemStock -> save($itemStock)) {

                // Display success message and redirect
                $this -> Session -> setFlash("New item stock  added.");
                $this -> redirect(array('controller' => 'item_stocks', 'action' => 'index'));

            } else {

                // Display failure message and redirect
                $this -> Session -> setFlash("Sorry. an error occurred.");
                $this -> redirect(array('controller' => 'item_stocks', 'action' => 'index'));

            }
        
        } else {

            // Check whether ID is null, if yes - redirect to index
            if($id == null){
                $this->Session->setFlash('No stock selected.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'item_stocks', 'action' => 'index'));
            }

            // Fetch the item stock by id
            $selectedStock = $this->ItemStock->findById($id);

            // Check whether resultset is null, if yes - redirect to index
            if($selectedStock == null){
                $this->Session->setFlash('No stock selected.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'item_stocks', 'action' => 'index'));
            }

            // Get vendors
            $vendors = $this -> Vendor -> find('list', array('conditions'=>array('Vendor.id NOT'=>'53e9c4b2-6c28-4a73-a8c3-3519bf642048'),'order' => 'Vendor.name ASC'));
            $this -> set('vendors', $vendors);            

            // Set the view variables to controller variable values and layout for the view
            $this->set('selectedStock',$selectedStock);
            $this -> set('page_title', 'Edit Item Stock');
            $this -> layout = 'base_layout';
        }
    }




    
    /*
    // Objective : This function deletes the selected item stock
    // Author : Ishan Sheth
    // Last Edit : 1/5/2014
    */
    public function delete($id=null) {

        // Check whether ID is null, if yes - redirect to index
        if($id == null){
            $this->Session->setFlash('Please choose a stock.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'item_stocks', 'action' => 'index'));
        }

        // Fetch the item stock by id
        $selectedItemStock = $this->ItemStock->findById($id);

        // Check whether resultset is null, if yes - redirect to index
        if($selectedItemStock == null){
            $this->Session->setFlash('Please choose a stock.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'item_stocks', 'action' => 'index'));
        }

        // Delete stock
        if($this->ItemStock->delete($selectedItemStock['ItemStock']['id'])){

            // Display success message and redirect    
            $this->Session->setFlash('Stock deleted.', 'default', array('class' => 'alert alert-success') , 'success');
            $this -> redirect(array('controller' => 'item_stocks', 'action' => 'index'));
        
        } else {

            // Display failure message and redirect
            $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'item_stocks', 'action' => 'index'));
        }

    }




    
    /*
    // Objective : This function deletes the selected item category
    // Author : Ishan Sheth
    // Last Edit : 10/8/2014
    */
    public function increment($id=null,$item_stock_id) {

        // Check whether it is a post request or not
        if ($this -> request -> is('post')) {

            // Get the data from post request
            $itemStock = $this -> request -> data;

            // Sanity check or redirect
            if($itemStock['ItemStock']['price'] < $itemStock['ItemStock']['discount_price'] ) {

                // Display error message and redirect
                $this->Session->setFlash('Discount price cannot be greater than price.', 'default', array('class' => 'alert alert-success') , 'success');
                $this -> redirect($this->referer());

            }            

            // Calculate discount percent from item price and discounted price
            if(!empty($itemStock['ItemStock']['discount_price']))
            {

                // Calculate discount percent if discount price is not empty
                $discount_percent = round(($itemStock['ItemStock']['price'] - $itemStock['ItemStock']['discount_price'])/$itemStock['ItemStock']['price'],2)*100;
            
            } else {

                // Calculate discount percent to 0 if discount price is empty
                $itemStock['ItemStock']['discount_price'] = $itemStock['ItemStock']['price'];
                $discount_percent = 0;

            }

            // Set discount percentage
            $itemStock['ItemStock']['discount_percentage'] = $discount_percent;

            // Add item stock
            if ($this -> ItemStock -> save($itemStock)) {

                // Display success message and redirect
                $this->Session->setFlash('New stock added.', 'default', array('class' => 'alert alert-success') , 'success');
                $this -> redirect(array('controller' => 'item_stocks', 'action' => 'index'));

            } else {

                // Display failure message and redirect
                $this->Session->setFlash('Sorry an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'item_stocks', 'action' => 'index'));

            }
        
        } else {

            // Check whether ID is null, if yes - redirect to index
            if($id == null){
                $this->Session->setFlash('No item selected.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'item_stocks', 'action' => 'index'));
            }

            // Fetch the item by id
            $selectedItem = $this->Item->findById($id);

            // Check whether resultset is null, if yes - redirect to index
            if($selectedItem == null){

                // Display failure message and redirect
                $this->Session->setFlash('No item selected.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'item_stocks', 'action' => 'index'));

            } elseif ($selectedItem['Item']['stock_type'] == 1) {

                // Display failure message and redirect, if stock type of item selected is set to infinite
                $this->Session->setFlash('Stock for item is set to infinite.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'item_stocks', 'action' => 'index'));
            }

            // Fetch the item stock by id
            $selectedItemStock = $this->ItemStock->findById($item_stock_id);

            // Check whether resultset is null, if yes - redirect to index
            if($selectedItemStock == null){
                $this->Session->setFlash('No item stock selected.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'item_stocks', 'action' => 'index'));
            }     

            // Get vendors
            $vendors = $this -> Vendor -> find('list', array('conditions'=>array('Vendor.id NOT'=>'53e9c4b2-6c28-4a73-a8c3-3519bf642048'),'order' => 'Vendor.name ASC'));
            $this -> set('vendors', $vendors); 

            // Set the view variables to controller variable values and layout for the view
            $this->set('selectedItem',$selectedItem);
            $this->set('selectedItemStock',$selectedItemStock);
            $this -> set('page_title', 'Add Item Stock');
            $this -> layout = 'base_layout';
        }
    }    




    
    /*
    // Objective : This function displays the item price for the current stock
    // Author : Ishan Sheth
    // Last Edit : 28/4/2014
    */
    public function getItemDisplayPrice($item_id=null,$intended_quantity=null) {

        // Fetch all the item stock by ID
        $selectedItemStocks = $this->ItemStock->find('all',array('conditions' => array('ItemStock.item_id' => $item_id),'order' => array('ItemStock.created ASC')));

        // Create an array
        $finalItemStock = array();

        // Get the current stock
        foreach ($selectedItemStocks as $selectedItemStock) {

            // Get available quantity
            $availableQuantity = 0;
            $availableQuantity = $selectedItemStock['ItemStock']['total_quantity'] - $selectedItemStock['ItemStock']['exhausted_quantity'];

            // Check whether available quantity is positive
            if($availableQuantity > 0){

                // Check whether sale is feasible
                if($availableQuantity >= $intended_quantity) {

                    // Set array and break, as we have got the item stock which we require
                    $finalItemStock['price'] = $selectedItemStock['ItemStock']['price'];
                    $finalItemStock['discount_price'] = $selectedItemStock['ItemStock']['discount_price'];
                    $finalItemStock['available_quantity'] = $availableQuantity;
                    $finalItemStock['stock_id'] = $selectedItemStock['ItemStock']['id'];
                    break;

                 } else {

                    // Move on to next iteration of item stock
                    continue;
                 }

            } else {

                // Move on to next iteration of item stock
                continue;
            }
        }

    }




    
    /*
    // Objective : This function depletes the item stock
    // Author : Ishan Sheth
    // Last Edit : 28/4/2014
    */
    public function depleteStock($stock_id=null,$buy_quantity=null) {   
        
        // Fetch stock by ID
        $selectedItemStock = $this->ItemStock->findById($stock_id);

        // Set final remaining stock quantity
        $finalQuantity = $selectedItemStock['ItemStock']['total_quantity'] - $selectedItemStock['ItemStock']['exhausted_quantity'] - $buy_quantity;

        // Check whether stock is available
        if($finalQuantity >= 0){

            // Deplete the stock quantity
            $selectedItemStock['ItemStock']['exhausted_quantity'] = $selectedItemStock['ItemStock']['exhausted_quantity'] + $buy_quantity;

            // Save item stock
            if ($this -> ItemStock -> save($selectedItemStock)) {

                // Display success message and redirect
                $this->Session->setFlash('Stock depleted.', 'default', array('class' => 'alert alert-success') , 'success');
                $this -> redirect(array('controller' => 'item_stocks', 'action' => 'index'));

            } else {
                
                // Display failure message and redirect
                $this->Session->setFlash('Sorry, could not deplete stock.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'item_stocks', 'action' => 'index'));

            }            
        }

    }

    public function search() {

        // Check whether it is a post request or not
        if ($this -> request -> is('post')) {

            // Get the data from post request
            $item = $this->request->data;
            $search = $item['ItemStock']['search_term'];

            // Check whether search term is null, if yes - redirect to index
            if(empty($search) || $search == "" || $search == null) {

                // Display failure message and redirect
                $this->Session->setFlash('Search item name blank.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'ItemStocks', 'action' => 'index'));
            }            

            // Find the item
            $finalSearchItems = $this->ItemStock->find('all',array(
                'conditions'=>array("OR" => array('Item.name LIKE'=>'%'.$search.'%')),
                'order'=>array('Item.item_category_id')
                ));
            $this -> set('item_stocks', $finalSearchItems);

            // Set the view variables to controller variable values and layout for the view
            $this -> set('page_title', 'Search Items');
            $this -> layout = 'base_layout';            

        } else {

            // Display failure message and redirect
            $this->Session->setFlash('Invalid page access.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'ItemStocks', 'action' => 'index'));
        
        }

    }





    /*
    // Objective : This function saves the item stock price via ajax call from index/search page
    // Author : Ishan Sheth
    // Last Edit : 9/8/2014
    */
    public function save_price_ajax($ajax_id=null,$ajax_price=null,$ajax_discount_price=null) {

            // Find the item
            $itemStock = $this->ItemStock->findById($ajax_id);
            $return_message = "";            

            // Set serverside validation
            if($itemStock['ItemStock']['id'] == "" || $itemStock['ItemStock']['price'] == "" ){
                $return_message = "You must set a price.";
            }

            // Set the prices according to the input to the model
            $itemStock['ItemStock']['price'] = $ajax_price;
            $itemStock['ItemStock']['discount_price'] = $ajax_discount_price;

            // Validate prices
            if($itemStock['ItemStock']['price']!=""){
                if($itemStock['ItemStock']['discount_price']==""){
                    $itemStock['ItemStock']['discount_price']=$itemStock['ItemStock']['price'];
                }
                if($itemStock['ItemStock']['discount_price']>$itemStock['ItemStock']['price']){
                    $return_message =  "Discounted price is greater than price.";
                }

                //Calculate percentage
                $itemStock['ItemStock']['discount_percentage'] = round(($itemStock['ItemStock']['price'] - $itemStock['ItemStock']['discount_price'])/$itemStock['ItemStock']['price'],2)*100;
            }
            else{
                $return_message =  "You must set a price.";
            }

            // Save the model
            if ($this->ItemStock ->save($itemStock)) {

                //This flash message has to be set in the view properly
                $return_message =  "Item price saved.";
            } else {
                //This flash message has to be set in the view properly
                $return_message =  "Sorry an error occurred.";
            }

        // Set the view variables to controller variable values and layout for the view
        $this->set('return_message',$return_message);
        $this -> layout = 'ajax';

    }    

}
?>