<?php
class ItemTypesController extends AppController {

	public $name = 'ItemTypes';
	public $uses = array('ItemType');




    
    /*
    // Objective : This function displays all the item types
    // Author : Ishan Sheth
    // Last Edit : 4/8/2014
    */
	public function index() {

		// Get all item types
		$itemTypes = $this -> ItemType -> find('all');
		$this -> set('item_types', $itemTypes);

		// Set the view variables to controller variable values and layout for the view
		$this -> set('page_title', 'View Item Types');
		$this -> layout = 'base_layout';
	}




    
    /*
    // Objective : This function adds the item type
    // Author : Ishan Sheth
    // Last Edit : 4/8/2014
    */
	public function add() {

		// Check whether it is a post request or not
		if ($this -> request -> is('post')) {

			// Get the data from post request
			$itemType = $this -> request -> data;	

			// Add item type
			if ($this -> ItemType -> save($itemType)) {

				// Display success message and redirect
				$this->Session->setFlash('New item type added.', 'default', array('class' => 'alert alert-success') , 'success');				
				$this -> redirect(array('controller' => 'item_types', 'action' => 'index'));

			} else {

				// Display failure message and redirect
				$this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
				$this -> redirect(array('controller' => 'item_types', 'action' => 'index'));
			}
		} else {

		}

        // Set the view variables to controller variable values and layout for the view
        $this -> set('page_title', 'Add Item Type');
        $this -> layout = 'base_layout';        
	}




    
    /*
    // Objective : This function saves the edited item type
    // Author : Ishan Sheth
    // Last Edit : 4/8/2014
    */
    public function edit($id=null) {

		// Check whether it is a post request or not
		if ($this -> request -> is('post')) {

			// Get the data from post request
			$itemType = $this -> request -> data;	

			// Save item type
			if ($this -> ItemType -> save($itemType)) {

				// Display success message and redirect
				$this->Session->setFlash('Item type saved.', 'default', array('class' => 'alert alert-success') , 'success');				
				$this -> redirect(array('controller' => 'item_types', 'action' => 'index'));

			} else {

				// Display failure message and redirect
				$this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
				$this -> redirect(array('controller' => 'item_types', 'action' => 'index'));
			}
		} else {

            // Check whether ID is null, if yes - redirect to index
            if($id == null){
                $this->Session->setFlash('Please choose an item type.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'item_categories', 'action' => 'index'));
            }

            // Fetch the item category by id
            $selectedType = $this->ItemType->findById($id);

            // Check whether resultset is null, if yes - redirect to index
            if($selectedType == null){
                $this->Session->setFlash('Please choose an item type.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'item_categories', 'action' => 'index'));
            }
            $this->set('selectedType',$selectedType);		

            // Set the view variables to controller variable values and layout for the view
            $this -> set('page_title', 'Edit Item Type');
            $this -> layout = 'base_layout';
		}
    }




    
    /*
    // Objective : This function deletes the selected item type
    // Author : Ishan Sheth
    // Last Edit : 28/4/2014
    */
    public function delete($id=null) {

        // Check whether ID is null, if yes - redirect to index
        if($id == null){

            // Display failure message and redirect
            $this->Session->setFlash('Please choose an item type.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'item_categories', 'action' => 'index'));
        }

        // Fetch the item category by id
        $selectedItemType = $this -> ItemType -> findById($id);

        // Check whether ID is null, if yes - redirect to index
        if($selectedItemType == null){

            // Display failure message and redirect
            $this->Session->setFlash('Please choose an item type.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'item_types', 'action' => 'index'));
        }

        // Delete selected item category
        if($this->ItemType->delete($selectedItemType['ItemType']['id'])){

            // Display success message and redirect
            $this->Session->setFlash('Item type deleted.', 'default', array('class' => 'alert alert-success') , 'success');
            $this -> redirect(array('controller' => 'item_types', 'action' => 'index'));
        }
        else{

            // Display failure message and redirect
            $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'item_types', 'action' => 'index'));
        }

    }    	

}
?>