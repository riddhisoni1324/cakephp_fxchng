<?php
class CouriersController extends AppController {

	public $name = 'Couriers';
	public $uses = array('Courier');





    /*
    // Objective : This function displays all the couriers
    // Author : Ishan Sheth
    // Last Edit : 1/8/2014
    */
	public function index() {

		// Get all couriers
		$couriers = $this -> Courier -> find('all');
		$this -> set('couriers', $couriers);

		// Set the view variables to controller variable values and layout for the view
		$this -> set('page_title', 'View Couriers');
		$this -> layout = 'base_layout';
	}




    
    /*
    // Objective : This function adds the courier
    // Author : Ishan Sheth
    // Last Edit : 2/8/2014
    */
	public function add() {

		// Check whether it is a post request or not
		if ($this -> request -> is('post')) {

			// Get the data from post request
			$courier = $this -> request -> data;

			// Add courier
			if ($this -> Courier -> save($courier)) {

				// Display success message and redirect
				$this -> Session -> setFlash('New courier added.', 'default', array('class' => 'alert alert-success'), 'success');
				$this -> redirect(array('controller' => 'couriers', 'action' => 'index'));

			} else {
				
				// Display failure message and redirect
				$this -> Session -> setFlash("Sorry. an error occurred.");
				$this -> redirect(array('controller' => 'couriers', 'action' => 'index'));
			}

		} else {

		}

		// Set the view variables to controller variable values and layout for the view
		$this -> set('page_title', 'Add Courier');
		$this -> layout = 'base_layout';		

	}




    
    /*
    // Objective : This function saves the edited courier
    // Author : Ishan Sheth
    // Last Edit : 2/8/2014
    */
	public function edit($id=null) {

		// Check whether it is a post request or not
		if ($this -> request -> is('post')) {
			
			// Get the data from post request
			$courier = $this -> request -> data;

			// Save courier
			if ($this -> Courier -> save($courier)) {

				// Display success message and redirect
				$this -> Session -> setFlash('Courier saved.', 'default', array('class' => 'alert alert-success'), 'success');
				$this -> redirect(array('controller' => 'couriers', 'action' => 'edit'));

			} else {
				
				// Display failure message and redirect
				$this -> Session -> setFlash("Sorry. an error occurred.");
				$this -> redirect(array('controller' => 'couriers', 'action' => 'index'));
			}

		} else {
			
			// Check whether ID is null, if yes - redirect to index
			if ($id == null) {
				$this -> Session -> setFlash("Sorry. Data not found.");
				$this -> redirect(array('controller' => 'couriers', 'action' => 'index'));
			}

			// Fetch the courier by id
			$courier = $this -> Courier -> findById($id);

			// Check whether resultset is null, if yes - redirect to index
			if ($courier == null) {
				$this -> Session -> setFlash("Sorry. Data not found.");
				$this -> redirect(array('controller' => 'couriers', 'action' => 'index'));
			}			

			// Set the view variables to controller variable values and layout for the view
			$this -> set('courier', $courier);
			$this -> set('page_title', 'Edit Courier');
			$this -> layout = 'base_layout';
			
		}
	}





    /*
    // Objective : This function deletes the selected courier
    // Author : Ishan Sheth
    // Last Edit : 2/8/2014
    */ 
	public function delete($id=null) {
			
        // Check whether ID is null, if yes - set error message and redirect
        if($id == null){
            $this->Session->setFlash('Please choose a couier.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'banners', 'action' => 'index'));
        }

        // Find the selected courier
        $selectedCourier = $this->Courier->findById($id);

        // Check whether resultset is null, if yes - set error message and redirect
        if($selectedCourier == null){
            $this->Session->setFlash('Please choose a courier.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'banners', 'action' => 'index'));
        }

        // Delete courier
		if ($this -> Courier -> delete($id)) {

			// Display success message and redirect
			$this -> Session -> setFlash('Courier deleted.', 'default', array('class' => 'alert alert-success'), 'success');
			$this -> redirect(array('controller' => 'couriers', 'action' => 'edit'));
		} else {
			
			// Display failure message and redirect
			$this -> Session -> setFlash("Sorry. an error occurred.");
			$this -> redirect(array('controller' => 'couriers', 'action' => 'index'));
		}

        // Set the view variables to controller variable values and layout for the view
        $this -> set('page_title', 'Delete Courier');
        $this -> layout = 'base_layout';		

	}

}
?>