<?php
App::uses('CakeTime', 'Utility');
App::uses('CakeEmail', 'Network/Email');
class OrdersController extends AppController {

	public $name = 'Orders';
	public $uses = array('Transaction','Order', 'OrderItem','User', 'UserAddress', 'Courier', 'OrderDispatch','City','State','Coupon', 'Item','Admin', 'ItemStock');




    
    /*
    // Objective : This function displays all the orders with pending dispatch and whose payment is done
    // Author : Ishan Sheth
    // Last Edit : 12/8/2014
    */   
	public function index() {
		
		// Load containable behavior on order item model to allow fetching of other models 
		$this->OrderItem->Behaviors->load('Containable');
		
		// Fetch the orders with pending dispatch
		$orders = $this -> OrderItem -> find('all',array(
		'conditions' => array('Order.status' => 1,array('OrderItem.order_dispatch_id'=>null)),
		'group' => 'Order.id',
		'contain' => array('Order','Order.User')
		));
		$this -> set('orders', $orders);

		// Set the view variables to controller variable values and layout for the view
		$this -> set('page_title', 'View Pending Dispatch Orders');
		$this -> layout = 'base_layout';
	}




	/*
	// Objective : This function displays the created orders(status=1)
	// Author : Bhaumik Gandhi
	// Last Edit : 21-May-2015
	*/   
	public function created() {
		
		// Load containable behavior on order item model to allow fetching of other models 
		$this->OrderItem->Behaviors->load('Containable');
		
		// Fetch the orders that only created
	       // we prepare our query, the cakephp way!
	        $this->paginate = array(
				'conditions' => array('Order.status' => 0),
				'contain' => array('Order','Order.User'),        	
	            'limit' => 10,
	            'group' => 'Order.id',
	            'order' => array('created' => 'desc')
	        );
	     
	        // we are using the 'OrderItem' model
	        $orders = $this->paginate('OrderItem');			

			// Set the view variables to controller variable values and layout for the view
			$this -> set('orders', $orders);
			$this -> set('page_title', 'View Created Orders');
			$this -> layout = 'base_layout';
		}



    
    /*
    // Objective : This function gets todays orders
    // Author : Ishan Sheth
    // Last Edit : 12/8/2014
    */
	public function todays() {
		
		// Get todays date
		$today = new DateTime();
		$tdate = $today->format('Y-m-d');
		
		// Get orders which are created today				
		$orders = $this -> Order -> find('all',array('conditions' => array('DATE(Order.created)' => $tdate,'Order.status' => array(0,1,2,3,4,5)), 'order'=>array('Order.created DESC')));
		//pr($orders);die();
		$final_orders = array();

		foreach ($orders as $tmp_orders) {
			
			// Get total no of order item
			$total_items = 0;
			foreach ($tmp_orders['OrderItem'] as $tmp_item) {
				$total_items++;
			}

			$created_by_details = $this->Admin->findById($tmp_orders['Order']['created_by']);
			$tmp_orders['Order']['order_by'] = $created_by_details['Admin']['name'];
			$tmp_orders['Order']['total_items'] = $total_items;

			array_push($final_orders, $tmp_orders);
		}		
		$this -> set('orders', $final_orders);
		// Set the view variables to controller variable values and layout for the view
		$this -> set('page_title', 'View Today\'s Orders');
		$this -> layout = 'base_layout';
	}




    
    /*
    // Objective : This function displays all the orders with finished payment and dispatch
    // Author : Ishan Sheth
    // Last Edit : 12/8/2014
    */
	public function completed() {
		
		// Load containable behavior on order item model to allow fetching of other models 
		$this->OrderItem->Behaviors->load('Containable');
		
		// Fetch the orders with finished payment and dispatch
        // we prepare our query, the cakephp way!
        $this->paginate = array(
			'conditions' => array('Order.status' => 2),
			'contain' => array('Order','Order.User'),        	
            'limit' => 10,
            'group' => 'Order.id',
            'order' => array('created' => 'desc')
        );
     
        // we are using the 'OrderItem' model
        $orders = $this->paginate('OrderItem');			

		// Set the view variables to controller variable values and layout for the view
		$this -> set('orders', $orders);
		$this -> set('page_title', 'View Completed Orders');
		$this -> layout = 'base_layout';
	}





    /*
    // Objective : This function displays all the orders which are manually canceled
    // Author : Ishan Sheth
    // Last Edit : 12/8/2014
    */
	public function canceled() {
		
		// Load containable behavior on order item model to allow fetching of other models 
		$this->OrderItem->Behaviors->load('Containable');
		
		// Fetch the orders with finished payment and dispatch
        // we prepare our query, the cakephp way!
        $this->paginate = array(
			'conditions' => array('Order.status' => -1),
			'contain' => array('Order','Order.User'),        	
            'limit' => 10,
            'group' => 'Order.id',
            'order' => array('created' => 'desc')
        );
     
        // we are using the 'OrderItem' model
        $orders = $this->paginate('OrderItem');			

		// Set the view variables to controller variable values and layout for the view
		$this -> set('orders', $orders);
		$this -> set('page_title', 'View Canceled Orders');
		$this -> layout = 'base_layout';
	}		




    
    /*
    // Objective : This function displays all the orders with pending dispatch and pending payment
    // Author : Ishan Sheth
    // Last Edit : 12/8/2014
    */ 	
	public function payment_incomplete() {
		
		// Load containable behavior on order item model to allow fetching of other models 
		$this->OrderItem->Behaviors->load('Containable');
		
		// Fetch the orders with pending payment and dispatch
        // we prepare our query, the cakephp way!
        $this->paginate = array(
			'conditions' => array('Order.status' => 0,array('OrderItem.order_dispatch_id'=>null),array('NOT'=>array('Order.user_id'=>null))),
			'contain' => array('Order','Order.User'),        	
            'limit' => 10,
            'group' => 'Order.id',
            'order' => array('created' => 'desc')
        );
     
        // we are using the 'OrderItem' model
        $orders = $this->paginate('OrderItem');	

		// Set the view variables to controller variable values and layout for the view
		$this -> set('orders', $orders);
		$this -> set('page_title', 'Payment Incomplete');
		$this -> layout = 'base_layout';
	}




    
    /*
    // Objective : This function displays the print view for invoice 
    // Author : Ishan Sheth
    // Last Edit : 13/5/2014
    */ 
	public function print_invoice($id) {

		// Check whether it is a post request or not
		if ($this -> request -> is('post')) {

		} else {

			// Fetch order by ID
			$order = $this -> Order -> findById($id);
			$transacton_details = $this->Transaction->find('first',array('conditions'=>array('Transaction.order_id'=>$id)));
			$this->set('invoice_details',$transacton_details);
			//pr($transacton_details);die();
			$this -> set('order', $order);

			//$transacton_details = $this->Transaction->find('all');
			// $in_flag = 0001;
			// foreach ($transacton_details as $transacton_detail) {
			// 			$tr_data['Transaction']['id'] = $transacton_detail['Transaction']['id'];
			// 			$tr_data['Transaction']['invoice_no'] = "BSBB14/15".$in_flag;
			// 			$this->Transaction->save($tr_data);
			// 			$in_flag++;
			// 		}		
			
			//$shipping = $this -> City -> findById($order['ShippingAddress']['city_id']);
			//$this -> set('shipping', $shipping);
			
			//$billing = $this -> City -> findById($order['BillingAddress']['city_id']);
			//$this -> set('billing', $billing);
			
			//$coupon = $this -> Coupon -> findById($order['Order']['coupon_id']);
			//$this -> set('coupon', $coupon);

			//$order_items = $this -> OrderItem -> find('all', array('conditions' => array('OrderItem.order_id' => $id), 'fields' => array('OrderItem.id', 'Item.name','OrderItem.quantity')));
			//$order_items_list = array();
			
			// Fetch order items by order ID
			$order_items = $this -> OrderItem -> find('all', array('conditions' => array('OrderItem.order_id' => $id)));
			//pr($order_items);
			$order_items_list = array();

			// Set array according to requirements so as to be displayed in the view for printing
			foreach ($order_items as $oitem) {

				// Create a new array
                $order_items_list[$oitem['OrderItem']['id']] = array();

                // Check whether variant name is set or not
                if (isset($oitem['Item']['variant_name'])) {

                	// Add variant name to the display name if it is set
					$order_items_list[$oitem['OrderItem']['id']]['name'] = $oitem['Item']['name'];
					$order_items_list[$oitem['OrderItem']['id']]['variant'] = $oitem['Item']['variant_name'];
					$order_items_list[$oitem['OrderItem']['id']]['qty'] = $oitem['OrderItem']['quantity'];
				} else {

					// Skip adding variant name 
					$order_items_list[$oitem['OrderItem']['id']]['name'] = $oitem['Item']['name'];
					$order_items_list[$oitem['OrderItem']['id']]['variant'] = "";
					$order_items_list[$oitem['OrderItem']['id']]['qty'] = $oitem['OrderItem']['quantity'];
				}

                // if($oitem['OrderItem']['item_params'] != ""){
                //    $order_items_list[$oitem['OrderItem']['id']]['item_params'] = json_decode($oitem['OrderItem']['item_params'],true);
                // }
                // else{
                //    $order_items_list[$oitem['OrderItem']['id']]['item_params'] = "";
                // } 
				
				// Check whether order item price is not blank
                if($oitem['OrderItem']['price'] != ""){

                	// Add order item price to the array
                    $order_items_list[$oitem['OrderItem']['id']]['price'] = $oitem['OrderItem']['price'];

                } else {

                	// Keep array index blank
                    $order_items_list[$oitem['OrderItem']['id']]['price'] = "";
                }

                // Over ride the array				
				$order_items_list[$oitem['OrderItem']['id']]['item_id'] = $oitem['Item']['id'];
			}
			//pr($order_items_list);die();
			$this -> set('order_items', $order_items_list);

			// Find all courieres by list
			// $couriers = $this -> Courier -> find('list');
			// $this -> set('couriers', $couriers); 

			// Set the view variables to controller variable values and layout for the view
			$page_title = "Invoice for Order Code : ".$order['Order']['code'];
			$this -> set('page_title', $page_title);
			$this -> set('order_code', $order['Order']['code']);
			$this -> layout = 'invoice_layout_blank';

		}
		$this -> layout = 'print_layout';
	}	




    
    /*
    // Objective : This function displays the selected order
    // Author : Ishan Sheth
    // Last Edit : 12/8/2014
    */	
	public function vieworder($id) {

		// Check whether it is a post request or not
		if ($this -> request -> is('post')) {

		} else {

			// Fetch order by ID
			$order = $this -> Order -> findById($id);
			$this -> set('order', $order);
			
			// Fetch shipping city by ID
			$shipping = $this -> City -> findById($order['ShippingAddress']['city_id']);
			$this -> set('shipping', $shipping);
			
			// Fetch billing city by ID
			$billing = $this -> City -> findById($order['BillingAddress']['city_id']);
			$this -> set('billing', $billing);
			
			// Fetch coupon by ID
			$coupon = $this -> Coupon -> findById($order['Order']['coupon_id']);
			$this -> set('coupon', $coupon);

			//$order_items = $this -> OrderItem -> find('all', array('conditions' => array('OrderItem.order_id' => $id), 'fields' => array('OrderItem.id', 'Item.name','OrderItem.quantity')));
			//$order_items_list = array();
			
			// Find all order items for the selected order
			$order_items = $this -> OrderItem -> find('all', array('conditions' => array('OrderItem.order_id' => $id), 'fields' => array('OrderItem.id', 'Item.name', 'Item.id','OrderItem.quantity','OrderItem.item_params')));
			$order_items_list = array();

			// Set the array according to requirements so as to be displayed on the view
			foreach ($order_items as $oitem) {

				// Create an empty array
                $order_items_list[$oitem['OrderItem']['id']] = array();

                // Check whether variant name is set or not
                if (isset($oitem['Item']['variant_name'])) {

                	// Add variant name to the display name
					$order_items_list[$oitem['OrderItem']['id']]['name'] = $oitem['Item']['name'] . " (" . $oitem['Item']['variant_name'] . ") x ". $oitem['OrderItem']['quantity'];

				} else {

					// Skip adding variant name to the display name
					$order_items_list[$oitem['OrderItem']['id']]['name'] = $oitem['Item']['name']. " x ". $oitem['OrderItem']['quantity'];
				}

				// Check whether item params are not null
                if($oitem['OrderItem']['item_params'] != ""){

                	// Add item params after decoding the json
                    $order_items_list[$oitem['OrderItem']['id']]['item_params'] = json_decode($oitem['OrderItem']['item_params'],true);

                } else {

                	// Set item params to blank
                    $order_items_list[$oitem['OrderItem']['id']]['item_params'] = "";
                }

                // Over ride the order items array
				$order_items_list[$oitem['OrderItem']['id']]['item_id'] = $oitem['Item']['id'];
			}
			$this -> set('order_items', $order_items_list);

			// Find all couriers by list
			/*$couriers = $this -> Courier -> find('list');
			$this -> set('couriers', $couriers);*/

			// Set the view variables to controller variable values and layout for the view
			$this -> set('page_title', 'View Order');
			$this -> layout = 'base_layout';

		}
	}	






    /*
    // Objective : This function cancels the selected order
    // Author : Ishan Sheth
    // Last Edit : 12/8/2014
    */
	public function cancel($id = null) {

		// Check whether it is a post request or not
		if ($this -> request -> is('post')) {
			
			// Get the data from post request
			$order = $this -> request -> data;

			// Save order
			if ($this -> Order -> save($order)) {

				//This flash message has to be set in the view properly
				$this -> Session -> setFlash('Order canceled.', 'default', array('class' => 'alert alert-success'), 'success');
				$this -> redirect(array('controller' => 'orders', 'action' => 'index'));

			} else {
				
				//This flash message has to be set in the view properly
                $this->Session->setFlash('Sorry an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'orders', 'action' => 'index'));

			}

		} else {
			
			// Check whether ID is null, if yes - redirect to index
			if ($id == null) {

				//This flash message has to be set in the view properly
				$this->Session->setFlash('You must select an order.', 'default', array('class' => 'alert alert-danger') , 'error');
				$this -> redirect(array('controller' => 'orders', 'action' => 'index'));

			} else {
				
				// Fetch the order by ID
				$order = $this -> Order -> findById($id);
				$this -> set('order', $order);

				// Set the view variables to controller variable values and layout for the view
				$this -> set('page_title', 'Cancel Order');
				$this -> layout = 'base_layout';
			}
		}
	}





    /*
    // Objective : This function cancels the selected order
    // Author : Ishan Sheth
    // Last Edit : 12/8/2014
    */
    public function mark_complete($id=null) {

    	// Check whether ID is null, if yes - redirect to index
        if($id == null){
            $this->Session->setFlash('Please choose an order.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'orders', 'action' => 'payment_incomplete'));
        }

        // Get the required order
        $selectedOrder = $this->Order->findById($id);

        // Check order is null, if yes - redirect to index
        if($selectedOrder == null){
            $this->Session->setFlash('Please choose an order.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'orders', 'action' => 'payment_incomplete'));
        }

        // Set the order status flag
        $selectedOrder['Order']['status']=1;

        // Save and redirect with proper message
        if($this->Order->save($selectedOrder)){
            $this->Session->setFlash('Order marked as complete.', 'default', array('class' => 'alert alert-success') , 'success');
            $this -> redirect(array('controller' => 'orders', 'action' => 'payment_incomplete'));
        }
        else{
            $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'orders', 'action' => 'payment_incomplete'));
        }
        
    }




    /*
    // Objective : This function is for autofill of mobile no
    // Author : Bhaumik Gandhi
    // Last Edit : 20-may-2015
    */

    public function find_mobile() {
       // Setting the recursive property for Item model to -1  
       $this->User->recursive = -1;

       //if ($this->request->is('ajax')) {

          $this->autoRender = false;
          $this->layout = 'ajax';

          $results = $this->User->find('all',
                    array('fields' => array('User.id','User.mobile','User.first_name','User.last_name','User.city'),
                    'conditions' => array('OR' => array('User.mobile LIKE' => '%'.$this->request->query['term'].'%'))));

          //$user_address = $thi

          $final_results = array();

          foreach ($results as $result) {
              $temp = array();  
              $temp['mobile'] = $result['User']['mobile'];
              $temp['id'] = $result['User']['id'];
              $temp['first_name'] = $result['User']['first_name'];
              $temp['last_name'] = $result['User']['last_name'];
              $temp['city'] = $result['User']['city'];
              //$temp['line1'] = $result['User']['line1'];

              array_push($final_results, $temp);
          }

          //$autofill = Set::extract('../Item/name', $results);           
          echo json_encode($final_results);

       //}
    }




/*
// Objective : This function create new order
// Author : Bhaumik Gandhi
// Last Edit : 19-may-2015
*/   
public function create_order() {

          $this->layout = 'base_layout';
          $this->set('page_title', 'Create new order');

          if ($this->request->is('post')) {

	          $data = $this->data;
	    
	          if ($data['flag'] == 0 ) {
	          	
	          	$data['User']['username'] = $data['User']['first_name'];
          		// save data in user table
	                    if ($this->User->save($data)) {	                    	

	                    	$user_address = array();

	                    	// Get Last inserted Id
	                    	$user_id = $this->User->getLastInsertId();

	                    	$user_address['UserAddress']['user_id'] = $user_id;

	                    	// Set User Name
	                    	$user_name = $data['User']['first_name']. " ". $data['User']['last_name'];	                    	
	                    	
	                    	$user_address['UserAddress']['name'] = $user_name;
	                    	$user_address['UserAddress']['line1'] = $data['User']['line1'];
	                    	$user_address['UserAddress']['line2'] = $data['User']['line2'];
	                    	$user_address['UserAddress']['area'] = $data['User']['area'];
	                    	$user_address['UserAddress']['pin_code'] = $data['User']['pin_code'];
	                    	
	                    	$city_name = $data['User']['city'];

	                    	$city_details = $this->City->find('all', array('conditions'=>array('Lower(City.name)'=>strtolower($city_name))));
	             
	                    	if($city_details) {
	                    		$city_id = $city_details[0]['City']['id'];
	                    		$user_address['UserAddress']['city_id'] = $city_id;
	                    	}
	                    	$user_address['UserAddress']['city_name'] = $city_name;
	                    	$user_address['UserAddress']['mobile'] = $data['User']['mobile'];
	                    	// Save User Address
	                    	if(!$this->UserAddress->save($user_address)) {
	                    		//Give Failure message.
					$this->Session->setFlash('Failed to save user address.', 'default', array('class' => 'alert alert-danger') , 'error');
	                    	}
	                    	else {
	                    		//This flash message has to be set in the view properly
					$this -> Session -> setFlash('Saved Successfully.', 'default', array('class' => 'alert alert-success'), 'success');
					$this -> redirect(array('controller' => 'orders', 'action' => 'create_order'));
	                    	}

	                    }
	                    else {
	                    	//Give Failure message.
				$this->Session->setFlash('Failed to save user data.', 'default', array('class' => 'alert alert-danger') , 'error');
			
	                    }

	          }
	          elseif ($data['flag'] == 1) {
	          	//save user_id
	          	$user_id = $data['OrderItem']['user_id'];
	          	$total_amount = $data['Items'][0]["Item"]["total_amount"]; 
	          	// save user_id in order table
	          	if ($user_id) {

	          		$order = array();
	          		$order['Order']['user_id'] = $user_id;
	       		$order['Order']['created_by'] = $this->activeUser['User']['id'];
	       		$order['Order']['total_amount'] = $total_amount;

	       		// get user address_id and save it to Order table in shipping_address_id
	       		$user_address_details = $this->UserAddress->findByUserId($user_id);
	       		if($user_address_details) {
	       			$shipping_address_id = $user_address_details['UserAddress']['id'];
	       		}
	       		//set shipping_address_id for saving order
	       		$order['Order']['shipping_address_id'] =$shipping_address_id; 
	       		$order['Order']['billing_address_id'] =$shipping_address_id;
	          		if($this->Order->save($order)) {
	          			// Get last insertId
	          			$order_id = $this->Order->getLastInsertId();

	          			$order_item = array();
		          		foreach ($data['Items'] as $tmp_order_items) {
		          			
		          			$order_item['OrderItem']['quantity'] = $tmp_order_items['Item']['quantity'];
		          			$order_item['OrderItem']['order_id'] = $order_id;
		          			$order_item['OrderItem']['item_id'] =  $tmp_order_items['Item']['variant_name'];
		          			$order_item['OrderItem']['price'] = $tmp_order_items['Item']['price'];
						// Create order_items
						$this->OrderItem->create();
						if(!$this->OrderItem->save($order_item)) {
							//Give Failure message.
							$this->Session->setFlash('Failed to save in order items.', 'default', array('class' => 'alert alert-danger') , 'error');			
						}
						
		          		}
	          		 	//This flash message has to be set in the view properly
						$this -> Session -> setFlash('Order Created Successfully.', 'default', array('class' => 'alert alert-success'), 'success');
						$this -> redirect(array('controller' => 'orders', 'action' => 'create_order'));
				}
	          		else {
	          			//Give Failure message.
					$this->Session->setFlash('Failed to create new order.', 'default', array('class' => 'alert alert-danger') , 'error');
			
	          		}

	          	}
	          	     
	          }
                  	
          }
          // Get all items and set
          $items = $this->Item->find('list', array('order'=>array('name')));
          $this->set("items", $items);
}




	/*
	// Objective : This function - get orders
	// Author : Bhaumik Gandhi
	// Last Edit : 22-May-2015
	*/   
	public function get_orders ($status=null, $id=null) {

		if($status !== null && $id === null) {
			if ($status === 'todays' || $status === "") {
					// Get todays date
					$today = new DateTime();
					$tdate = $today->format('Y-m-d');
					
					// Get orders which are created today				
					$orders = $this -> Order -> find('all',array('conditions' => array('DATE(Order.created)' => $tdate,'Order.status' => array(0,1,2,3,4,5)), 'order'=>array('Order.created DESC')));
					
					$final_orders = array();

					foreach ($orders as $tmp_orders) {
						
						// Get total no of order item
						$total_items = 0;
						foreach ($tmp_orders['OrderItem'] as $tmp_item) {
							$total_items++;
						}

						$created_by_details = $this->Admin->findById($tmp_orders['Order']['created_by']);
						$tmp_orders['Order']['order_by'] = $created_by_details['Admin']['name'];
						$tmp_orders['Order']['total_items'] = $total_items;

						array_push($final_orders, $tmp_orders);
					}		
					$this -> set('orders', $final_orders);
					$this->set('status', 'todays');
			}
			elseif ($status === 'created') {
				// Get todays date
				$today = new DateTime();
				$tdate = $today->format('Y-m-d');
				
				// Get orders which are created today				
				$orders = $this -> Order -> find('all',array('conditions' => array('Order.status' => array(0)), 'order'=>array('Order.created DESC')));
				
				$final_orders = array();

				foreach ($orders as $tmp_orders) {
					
					// Get total no of order item
					$total_items = 0;
					foreach ($tmp_orders['OrderItem'] as $tmp_item) {
						$total_items++;
					}

					$created_by_details = $this->Admin->findById($tmp_orders['Order']['created_by']);
					$tmp_orders['Order']['order_by'] = $created_by_details['Admin']['name'];
					$tmp_orders['Order']['total_items'] = $total_items;

					array_push($final_orders, $tmp_orders);
				}		
				$this -> set('orders', $final_orders);
				$this->set('status', 'created');
			}
			elseif ($status === 'processed') {
				// Get todays date
				$today = new DateTime();
				$tdate = $today->format('Y-m-d');
				
				// Get orders which are created today				
				$orders = $this -> Order -> find('all',array('conditions' => array('Order.status' => array(1)), 'order'=>array('Order.created DESC')));
				
				$final_orders = array();

				foreach ($orders as $tmp_orders) {
					
					// Get total no of order item
					$total_items = 0;
					foreach ($tmp_orders['OrderItem'] as $tmp_item) {
						$total_items++;
					}

					$created_by_details = $this->Admin->findById($tmp_orders['Order']['created_by']);
					$tmp_orders['Order']['order_by'] = $created_by_details['Admin']['name'];
					$tmp_orders['Order']['total_items'] = $total_items;

					array_push($final_orders, $tmp_orders);
				}	
					
				$this -> set('orders', $final_orders);
				$this->set('status', 'processed');
			}
			elseif ($status === 'collected') {
				// Get todays date
				$today = new DateTime();
				$tdate = $today->format('Y-m-d');
				
				// Get orders which are created today				
				$orders = $this -> Order -> find('all',array('conditions' => array('Order.status' => array(2)), 'order'=>array('Order.created DESC')));
				
				$final_orders = array();

				foreach ($orders as $tmp_orders) {
					
					// Get total no of order item
					$total_items = 0;
					foreach ($tmp_orders['OrderItem'] as $tmp_item) {
						$total_items++;
					}

					$created_by_details = $this->Admin->findById($tmp_orders['Order']['created_by']);
					$tmp_orders['Order']['order_by'] = $created_by_details['Admin']['name'];
					$tmp_orders['Order']['total_items'] = $total_items;

					array_push($final_orders, $tmp_orders);
				}		
				$this -> set('orders', $final_orders);
				$this->set('status', 'collected');
			}
			elseif ($status === 'invoice') {
				// Get todays date
				$today = new DateTime();
				$tdate = $today->format('Y-m-d');
				
				// Get orders which are created today				
				$orders = $this -> Order -> find('all',array('conditions' => array('Order.status' => array(3)), 'order'=>array('Order.created DESC')));
				
				$final_orders = array();

				foreach ($orders as $tmp_orders) {
					
					// Get total no of order item
					$total_items = 0;
					foreach ($tmp_orders['OrderItem'] as $tmp_item) {
						$total_items++;
					}

					$created_by_details = $this->Admin->findById($tmp_orders['Order']['created_by']);
					$tmp_orders['Order']['order_by'] = $created_by_details['Admin']['name'];
					$tmp_orders['Order']['total_items'] = $total_items;

					array_push($final_orders, $tmp_orders);
				}		
				$this -> set('orders', $final_orders);
				$this->set('status', 'invoice');				
			}
			elseif ($status === 'ontheway') {
				// Get todays date
				$today = new DateTime();
				$tdate = $today->format('Y-m-d');
				
				// Get orders which are created today				
				$orders = $this -> Order -> find('all',array('conditions' => array('Order.status' => array(4)), 'order'=>array('Order.created DESC')));
				
				$final_orders = array();

				foreach ($orders as $tmp_orders) {
					
					// Get total no of order item
					$total_items = 0;
					foreach ($tmp_orders['OrderItem'] as $tmp_item) {
						$total_items++;
					}

					$created_by_details = $this->Admin->findById($tmp_orders['Order']['created_by']);
					$tmp_orders['Order']['order_by'] = $created_by_details['Admin']['name'];
					$tmp_orders['Order']['total_items'] = $total_items;

					array_push($final_orders, $tmp_orders);
				}		
				$this -> set('orders', $final_orders);
				$this->set('status', 'ontheway');
			}
			elseif ($status === 'delivered') {
				// Get todays date
				$today = new DateTime();
				$tdate = $today->format('Y-m-d');
				
				// Get orders which are created today				
				$orders = $this -> Order -> find('all',array('conditions' => array('Order.status' => array(5)), 'order'=>array('Order.created DESC')));
				
				$final_orders = array();

				foreach ($orders as $tmp_orders) {
					
					// Get total no of order item
					$total_items = 0;
					foreach ($tmp_orders['OrderItem'] as $tmp_item) {
						$total_items++;
					}

					$created_by_details = $this->Admin->findById($tmp_orders['Order']['created_by']);
					$tmp_orders['Order']['order_by'] = $created_by_details['Admin']['name'];
					$tmp_orders['Order']['total_items'] = $total_items;

					array_push($final_orders, $tmp_orders);
				}		
				$this -> set('orders', $final_orders);
				$this->set('status', 'delivered');
			}
		}
		else {	

			if($status === 'created') {
				$order_details = $this->Order->findById($id);
				$order_details['Order']['status'] = 0;
				
				if ($this->Order->save($order_details)) {
					//This flash message has to be set in the view properly
					$this -> Session -> setFlash('Successfully, Order set', 'default', array('class' => 'alert alert-success'), 'success');
					$this -> redirect(array('controller' => 'orders', 'action' => 'get_orders/created'));
				}
				else {
					 $this->Session->setFlash('Sorry, order not set.', 'default', array('class' => 'alert alert-danger') , 'error');
				}
			}
			elseif ($status === 'processed') {
				$order_details = $this->Order->findById($id);
				$order_details['Order']['status'] = 1;
				
				if ($this->Order->save($order_details)) {
					//This flash message has to be set in the view properly
					$this -> Session -> setFlash('Successfully, Order set', 'default', array('class' => 'alert alert-success'), 'success');
					$this -> redirect(array('controller' => 'orders', 'action' => 'get_orders/processed'));
				}	
				else {
					 $this->Session->setFlash('Sorry, order not set.', 'default', array('class' => 'alert alert-danger') , 'error');
				}			
			}
			elseif ($status === 'collected') {
				$order_details = $this->Order->findById($id);
				$order_details['Order']['status'] = 2;
				
				if ($this->Order->save($order_details)) {
					//This flash message has to be set in the view properly
					$this -> Session -> setFlash('Successfully, Order set', 'default', array('class' => 'alert alert-success'), 'success');
					$this -> redirect(array('controller' => 'orders', 'action' => 'get_orders/collected'));
				}	
				else {
					 $this->Session->setFlash('Sorry, order not set.', 'default', array('class' => 'alert alert-danger') , 'error');
				}					
			}
			elseif ($status === 'invoice') {
				$order_details = $this->Order->findById($id);
				$order_details['Order']['status'] = 3;
				
				if ($this->Order->save($order_details)) {
					//This flash message has to be set in the view properly
					$this -> Session -> setFlash('Successfully, Order set', 'default', array('class' => 'alert alert-success'), 'success');
					$this -> redirect(array('controller' => 'orders', 'action' => 'get_orders/invoice'));
				}	
				else {
					 $this->Session->setFlash('Sorry, order not set.', 'default', array('class' => 'alert alert-danger') , 'error');
				}					
			}
			elseif ($status === 'ontheway') {
				$order_details = $this->Order->findById($id);
				$order_details['Order']['status'] = 4;
				
				if ($this->Order->save($order_details)) {
					//This flash message has to be set in the view properly
					$this -> Session -> setFlash('Successfully, Order set to created', 'default', array('class' => 'alert alert-success'), 'success');
					$this -> redirect(array('controller' => 'orders', 'action' => 'get_orders/ontheway'));
				}	
				else {
					 $this->Session->setFlash('Sorry, order not set.', 'default', array('class' => 'alert alert-danger') , 'error');
				}					
			}
			elseif ($status === 'delivered') {
				$order_details = $this->Order->findById($id);
				$order_details['Order']['status'] = 5;
				
				if ($this->Order->save($order_details)) {
					//This flash message has to be set in the view properly
					$this -> Session -> setFlash('Successfully, Order set to created', 'default', array('class' => 'alert alert-success'), 'success');
					$this -> redirect(array('controller' => 'orders', 'action' => 'get_orders/delivered'));
				}	
				else {
					 $this->Session->setFlash('Sorry, order not set.', 'default', array('class' => 'alert alert-danger') , 'error');
				}					
			}
		}
		// Set the view variables to controller variable values and layout for the view
		$this -> set('page_title', 'View Orders');
		$this -> layout = 'base_layout';
	}




	/*
	// Objective : This function - edit orders
	// Author : Bhaumik Gandhi
	// Last Edit : 22-May-2015
	*/   
	public function edit_order ($ordr_id=null,$usr_id=null) {


          $this->layout = 'base_layout';
          $this->set('page_title', 'Create new order');
          $this->set('ordr_id',$ordr_id);
          $this->set('user_id',$usr_id);
          if ($this->request->is('post')) {

	          $data = $this->data;
	         $tmp_user_address = $this->UserAddress->findByUserId($usr_id);
	          if ($data['flag'] == 0 ) {
	          	
	          	
	          	$data['User']['username'] = $data['User']['first_name'];
	          	$data['User']['id'] = $usr_id;
	          	
          		// save data in user table
	                    if ($this->User->save($data)) {	                    	
	                    		//pr($data);
	                    	$user_address = array();

	                    	//find user_address_id
	                    
	                    	
	                    	// Get Last inserted Id
	                    	$user_id = $data["User"]['id'];
	                    	//pr($user_id);
	                    	$user_address['UserAddress']['user_id'] = $user_id;
	                    	
	                    	// Set User Name
	                    	$user_name = $data['User']['first_name']. " ". $data['User']['last_name'];	                    	
	                    	
	                    	$user_address['UserAddress']['name'] = $user_name;
	                    	$user_address['UserAddress']['line1'] = $data['User']['line1'];
	                    	$user_address['UserAddress']['line2'] = $data['User']['line2'];
	                    	$user_address['UserAddress']['area'] = $data['User']['area'];
	                    	$user_address['UserAddress']['pin_code'] = $data['User']['pin_code'];
	                    	$user_address['UserAddress']['id'] = $tmp_user_address['UserAddress']['id'];
	                    	
	                    	$city_name = $data['User']['city'];

	                    	$city_details = $this->City->find('all', array('conditions'=>array('Lower(City.name)'=>strtolower($city_name))));
	             
	                    	if($city_details) {
	                    		$city_id = $city_details[0]['City']['id'];
	                    		$user_address['UserAddress']['city_id'] = $city_id;
	                    	}
	                    	$user_address['UserAddress']['city_name'] = $city_name;
	                    	$user_address['UserAddress']['mobile'] = $data['User']['mobile'];
	                    
	                    	// Save User Address
	                    	if(!$this->UserAddress->save($user_address)) {
	                    		//Give Failure message.
					$this->Session->setFlash('Failed to save user address.', 'default', array('class' => 'alert alert-danger') , 'error');
	                    	}
	                    	else {
	                    		//This flash message has to be set in the view properly
					$this -> Session -> setFlash('Saved Successfully.', 'default', array('class' => 'alert alert-success'), 'success');
					$this -> redirect(array('controller' => 'orders', 'action' => 'edit_order', $ordr_id, $usr_id));
	                    	}

	                    }
	                    else {
	                    	//Give Failure message.
				$this->Session->setFlash('Failed to save user data.', 'default', array('class' => 'alert alert-danger') , 'error');
			
	                    }

	          }
	          elseif ($data['flag'] == 1) {
	          	//save user_id

	          	// $user_id = $data['OrderItem']['user_id'];
	          	$total_amount = $data['Items'][0]["Item"]["total_amount"]; 
	          	// save user_id in order table
	          	//pr($data);die();
	          	foreach ($data['Items'] as $tmp_order_items) {
	          		$this->OrderItem->create();
          			if(isset($tmp_order_items['Item']['id']))
          			{
          				$order_item['OrderItem']['id'] = $tmp_order_items['Item']['id'];
	          			$order_item['OrderItem']['quantity'] = $tmp_order_items['Item']['quantity'];
	          			$order_item['OrderItem']['order_id'] = $ordr_id;
	          			$order_item['OrderItem']['item_id'] =  $tmp_order_items['Item']['variant_name'];
	          			$order_item['OrderItem']['price'] = $tmp_order_items['Item']['price'];
	          			
	          			
          			}
          			else
          			{	
          				unset($tmp_order_items['OrderItem']['id']);
          				$order_item['OrderItem']['quantity'] = $tmp_order_items['Item']['quantity'];
	          			$order_item['OrderItem']['order_id'] = $ordr_id;
	          			$order_item['OrderItem']['item_id'] =  $tmp_order_items['Item']['variant_name'];
	          			$order_item['OrderItem']['price'] = $tmp_order_items['Item']['price'];
	          			
	          			
          			}
          			
          			
          			if(!$this->OrderItem->save($order_item)) {
					//Give Failure message.
				$this->Session->setFlash('Failed to save in order items.', 'default', array('class' => 'alert alert-danger') , 'error');			
				}
          			
				
			}
          		
		 	//This flash message has to be set in the view properly
			$this -> Session -> setFlash('Order Edited Successfully.', 'default', array('class' => 'alert alert-success'), 'success');
			// pr($ordr_id);
			// pr($usr_id);die();
			$this -> redirect(array('controller' => 'orders', 'action' => 'edit_order',$ordr_id, $usr_id));
				
	          	
	          	     
	          }
                  	
          }
          // get user details
          	$order_details = $this->Order->findById($ordr_id);

          	$this->set('details', $order_details);
          	//pr($order_details);
          // Get all items and set
          $items = $this->Item->find('list', array('order'=>array('name')));
          $this->set("items", $items);

	}




    /*
    // Objective : This function shows the item in ajax mode
    // Author : Bhaumik Gandhi
    // Last Edit : 20-May-2015
    */  
    public function json($mobile=null){

        // Check whether ID is null, if yes - set error message
        if($mobile == null){
            $this->set('message','error');
        }

        // Find the selected item
        $selectedItem = $this->UserAddress->find('first', array('conditions'=>array('User.mobile'=>$mobile)));

        // Check whether resultset is null
        if($selectedItem == null) {

            // Set error message
            $this->set('message','error');
        } else {               
          $this->set('message',json_encode($selectedItem));
        }
        // Set the layout for the view
        $this->layout = 'ajax_layout';
    }




    /*
    // Objective : This function gets all items
    // Author : Bhaumik Gandhi
    // Last Edit : 20-May-2015
    */
    public function get_items() {

        // Set ajax layout
        $this->layout = 'ajax';

        //$items = $this -> Item -> find('all');
        $items = $this->Item->find('all', array('order'=>array('Item.name')));
        
        if($items) {
            
            $content = '<option value="" >Select Item</option>';

            foreach ($items as $item) {
                $content .= '<option value="'.$item['Item']['id'].'" >'.$item['Item']['name'].'</option>';
            }

        } else {

            $content = '<option value="" >Select Item</option>';           

        }

        echo $content;
    }




    /*
    // Objective : This function gets all variant of item
    // Author : Bhaumik Gandhi
    // Last Edit : 21-May-2015
    */
    public function get_variant($id=null) {

        // Set ajax layout
        $this->layout = 'ajax';

        $variant_items = $this->Item->find('all',array('conditions'=>array('OR'=>array('Item.id'=>$id, 'Item.item_id'=>$id))));
      
        if($variant_items) {

            $content = '<option value="" >Select Variant</option>';

            foreach ($variant_items as $item) {
                $content .= '<option value="'.$item['Item']['id'].'" >'.$item['Item']['variant_name'].'</option>';
            }

        } else {

            $content = '<option value="" >Select Variant</option>';           

        }

        echo $content;
    }
   



    /*
    // Objective : This function gets item price from item_stock table
    // Author : Bhaumik Gandhi
    // Last Edit : 23-May-2015
    */
    public function get_item_price($id=null) {
    	// set ajax layout
    	$this->layout = 'ajax';

    	$item_stock_details = $this->ItemStock->findByItemId($id);
    	$price = $item_stock_details['ItemStock']['price'];
    	echo $price;
    }




/*
// Objective : This function gives json of order_items of a specific order
// Author : Bhaumik Gandhi
// Last Edit : 24-May-2015
*/    
public function getOrderItems($id) {

       // Set layout for controller
       $this->layout = 'ajax_layout';
       
       // Get all order items
       $order_items = $this->OrderItem->find('all',array('conditions'=>array('OrderItem.order_id'=>$id)));
      //pr($order_items);die();
      //  foreach ($order_items as $key => $value) {
       	
      //  	$item_vars = $this->Item->find('all',array('conditions'=>array('OR'=>array('Item.id'=>$value['Item']['id'], 'Item.item_id'=>$value['Item']['id']))));       	
      //  	$all_item_var = array();
      //  	foreach ($item_vars as $key1 => $item_var) {
			   // $all_item_var[$item_var['Item']['id']] = $item_var['Item']['variant_name'];
      //  	}
      //  	$value[$key]['Item'] = $all_item_var;
      //  }
      //pr($all_item_var);die();
      //	pr($order_items);die();
       $this->set('order_items',$order_items);
       $this->set('item_arr_size',sizeof($order_items));
       //pr($order_items);die();

       $items = $this->Item->find('list', array('order'=>array('Item.name')));
       $this->set('item_list', $items);
      
       
}
 public function ajax_add_row($count){
 	$items = $this->Item->find('list', array('order'=>array('Item.name')));
       $this->set('item_list', $items);
    	$this->set('count',$count);
      
    	// Set ajax layout
        $this->layout = 'ajax_layout';
    }




}
?>