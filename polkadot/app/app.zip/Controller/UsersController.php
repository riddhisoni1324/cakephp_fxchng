<?php
App::uses('CakeTime', 'Utility');
App::uses('CakeEmail', 'Network/Email');

class UsersController extends AppController {

	public $name = 'Users';
	var $uses = array('User', 'UserAddress','EmailTemplate');



	

    /*
    // Objective : This function displays all the registered users
    // Author : Ishan Sheth
    // Last Edit : 12/8/2014
    */  	
	public function index() {
		
        // we prepare our query, the cakephp way!
        $this->paginate = array(
            'limit' => 10,
            'conditions' => array('User.is_franchise'=> 0),
            'order' => array('User.modified' => 'desc')
        );
     
        // we are using the 'User' model
        $users = $this->paginate('User');

        // Set the view variables to controller variable values and layout for the view		
        $this -> set('users', $users);
		$this -> set('page_title', 'View Users');
		$this -> layout = 'base_layout';		
	
	}





    /*
    // Objective : This function displays the registered user
    // Author : Ishan Sheth
    // Last Edit : 12/8/2014
    */
	public function viewuser($id) {
		if ($this -> request -> is('post')) {

		} else {

			// Get the specified user
			$user = $this -> User -> findById($id);
			$this -> set('user', $user);
			
			// Set the view variables to controller variable values and layout for the view
			$this -> set('page_title', 'View User');
			$this -> layout = 'base_layout';
		}
	}	





    /*
    // Objective : This function exports the email ids of all users in csv format
    // Author : Ishan Sheth
    // Last Edit : 12/8/2014
    */
	public function export_csv() {
		if ($this -> request -> is('post')) {

			// Get all user email addresses only
			$this->User->Behaviors->load('Containable');
			$users = $this -> User -> find('all',array('conditions' => array('User.is_franchise NOT'=> 0),'fields' => array('User.username'),'contain'=>array()));
			
			// Get the email addresses into csv format
			$exported_csv = "";
			foreach($users as $user) {
				$exported_csv .= $user['User']['username'].",";
			}
			$exported_csv = substr($exported_csv,0,-1);			
			
			// Set the view variables to controller variable values and layout for the view
			$this -> set('users', $users);			
			$this -> set('page_title', 'Export Users CSV');
			$this -> layout = 'base_layout';			
		
		} else {
			
			// Set the view variables to controller variable values and layout for the view
			$this -> set('page_title', 'Export Users CSV');
			$this -> layout = 'base_layout';
		}
	}





    /*
    // Objective : This function displays all the registered franchise users
    // Author : Ishan Sheth
    // Last Edit : 12/8/2014
    */  	
	public function franchise_users() {
		
        // we prepare our query, the cakephp way!
        $this->paginate = array(
            'limit' => 10,
            'conditions' => array('User.is_franchise'=> 1),
            'order' => array('User.modified' => 'desc')
        );
     
        // we are using the 'User' model
        $users = $this->paginate('User');

        // Set the view variables to controller variable values and layout for the view		
        $this -> set('users', $users);
		$this -> set('page_title', 'View Franchise Users');
		$this -> layout = 'base_layout';		
	
	}

    public function edit_franchise_user($id=null) {

       if($this->request->is('post')) {

        if ($this -> User -> save($this->data)) {
            $this->Session->setFlash('Edit franchise user successfully.', 'default', array('class' => 'alert alert-success') , 'success');
            $this -> redirect(array('controller' => 'users', 'action' => 'franchise_users'));
        }
        else {
            $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'users', 'action' => 'franchise_users'));
        }

       } else { 

         if($id==null) {
            $this->Session->setFlash('Please, select franchise user.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'users', 'action' => 'add_franchise_user'));
        }

        $user_data = $this->User->findById($id);
        $this->set('user_data', $user_data);

       }

       $this -> set('page_title', 'Edit Franchise Users');
       $this -> layout = 'base_layout';     


       

    }



    /*
    // Objective : This function adds registered franchise user
    // Author : Ishan Sheth
    // Last Edit : 12/8/2014
    */
	public function add_franchise_user() {

        // Check whether the request is a post request
        if ($this -> request -> is('post')) {

            // Get the data from post request 
            $fuser = $this -> request -> data;
            
            $existing = $this ->User->findByUsername($fuser['User']['username']);
            if($existing)
            {
                $this->Session->setFlash('Sorry, Franchise User Exist.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'users', 'action' => 'add_franchise_user'));
            }
            
            // Set respective preprocessing to data before saving data
            $fuser['User']['is_franchise'] = 1;
            $fuser['User']['is_active'] = 1;

            // Add franchise user
            if ($this -> User -> save($fuser)) {

                //Get EmailTemplate
                $add_franchise_user_template = $this->EmailTemplate->find('first',array('conditions'=>array('EmailTemplate.alias'=>'add_franchise_user')));

                // Send Mail
                if($add_franchise_user_template != null)
                {
                    $Email = new CakeEmail('default');

                    $subject = $add_franchise_user_template['EmailTemplate']['title'];
                    $message =  html_entity_decode($add_franchise_user_template['EmailTemplate']['content']);
                    $message = str_replace("{user_name}",$fuser['User']['first_name'],$message);                    
                    $message = str_replace("{user_password}",$fuser['User']['password'],$message);                    

                    $Email->emailFormat('html');
                    $Email->template('default');
                    $Email->to($fuser['User']['username']);
                    $Email->subject($subject);
                    $Email->send($message);

                }            	

                // Display success message and redirect
                $this->Session->setFlash('New franchise user added.', 'default', array('class' => 'alert alert-success') , 'success');
                $this -> redirect(array('controller' => 'users', 'action' => 'franchise_users'));
            } else {

                // Display failure message and redirect
                $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'users', 'action' => 'franchise_users'));
            }

        } 

        // Set the view variables to controller variable values and layout for the view	
		$this -> set('page_title', 'Add Franchise User');
		$this -> layout = 'base_layout';

		

		// This is to add a user for testing purpose
		/*$newUser = array();

		$newUser['User']['username'] = "test@test.com";
		$newUser['User']['password'] = "test123";
		$newUser['User']['mobile'] = "9999988888";

		if ($this -> User -> save($newUser)) {
			$this -> Session -> setFlash("User has been added.");
		} else {
			$this -> Session -> setFlash("NOPE.");
		}
		$this -> redirect(array('controller' => 'users', 'action' => 'index'));*/


	}
	
		



}
?>
