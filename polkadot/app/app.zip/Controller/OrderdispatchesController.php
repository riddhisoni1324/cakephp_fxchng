<?php

App::uses('CakeEmail', 'Network/Email');
//include_once('../Plugin/sms_engine/sms.php');
class OrderDispatchesController extends AppController {

	public $name = 'Order Dispatches';
	public $uses = array('Order', 'OrderItem', 'Courier', 'OrderDispatch','City','EmailTemplate','State','Coupon');




    
    /*
    // Objective : This function displays all the order dispatches
    // Author : Ishan Sheth
    // Last Edit : 12/8/2014
    */ 
	public function index() {

        // Load containable behavior on OrderDispatch model to allow fetching of other models 
        $this->OrderDispatch->Behaviors->load('Containable');
        
        // we prepare our query, the cakephp way!
        $this->paginate = array(         
            'limit' => 10,
            'order' => array('created' => 'desc')
        );
     
        // we are using the 'OrderItem' model
        $order_dispatches = $this->paginate('OrderDispatch'); 

        // Set the view variables to controller variable values and layout for the view
        $this -> set('order_dispatches', $order_dispatches);
		$this -> set('page_title', 'View Order Dispatches');
		$this -> layout = 'base_layout';
	}




    
    /*
    // Objective : This function adds the item category
    // Author : Ishan Sheth
    // Last Edit : 12/8/2014
    */
	public function add($id=null) {

        // Check whether it is a post request or not
		if ($this -> request -> is('post')) {

            // Get the data from post request
			$odispatch = $this -> request -> data;

            // Set null if courier is not set
            if($odispatch['OrderDispatch']['courier_id']==""){
                $odispatch['OrderDispatch']['courier_id'] = null;
            }

            // Display failure message and redirect
            if(sizeof($odispatch['OrderDispatch']['order_item_ids'])==0){
                $this -> Session -> setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger'), 'error');
                $this -> redirect($this->referer());
            }

            // Save order dispatch
			if ($this -> OrderDispatch -> save($odispatch)) {

                // Get order dispatch ID
				$disp_id = $this -> OrderDispatch -> getInsertId();

				foreach ($odispatch['OrderDispatch']['order_item_ids'] as $order_item_id) {
						
                    // Find order item by ID
					$order_item = $this -> OrderItem -> findById($order_item_id);
					
                    // Set dispatch ID and save order item
					$order_item['OrderItem']['order_dispatch_id'] = $disp_id;
					$this -> OrderItem -> save($order_item);
				}

                // Check whether all items in Order are dispatched
                $total_items = $this->OrderItem->find('count',array('conditions'=>array('OrderItem.order_id'=>$odispatch['OrderDispatch']['order_id'])));
                $dispatched_items = $this->OrderItem->find('count',array('conditions'=>array('OrderItem.order_id'=>$odispatch['OrderDispatch']['order_id'],array('NOT'=>array('OrderItem.order_dispatch_id'=>null)))));
                $selectedOrder = $this->Order->findById($odispatch['OrderDispatch']['order_id']);
                // Change order status if all items are to be dispatched

                if($total_items==$dispatched_items){

                    // Change order status
                    $selectedOrder = $this->Order->findById($odispatch['OrderDispatch']['order_id']);
                   
                    $selectedOrder['Order']['status']=2;

                    // Save order
                    $this->Order->save($selectedOrder);
                }

                //Get EmailTemplate
                $order_delivered_template = $this->EmailTemplate->find('first',array('conditions'=>array('EmailTemplate.alias'=>'order_delivered')));

                // Send Mail
                if($order_delivered_template != null)
                {
                    $Email = new CakeEmail('default');

                    $subject = $order_delivered_template['EmailTemplate']['title'];
                    $message =  html_entity_decode($order_delivered_template['EmailTemplate']['content']);
                    $message = str_replace("{user_name}",$selectedOrder['User']['first_name'],$message);
                    $message = str_replace("{order_id}",$selectedOrder['Order']['code'],$message);

                    $Email->emailFormat('html');
                    $Email->template('default');
                    //$Email->to($selectedOrder['User']['username']);

                    if($selectedOrder['User']['user_email'] == null)
                    {
                        $Email->to($selectedOrder['User']['username']);
                        $Email->bcc(array('brewshop@brewberrys.com','dhrupad.patel@actonate.com'));
                        
                    }
                    else
                    {
                        $Email->to(array($selectedOrder['User']['username'],$selectedOrder['User']['user_email']));
                        $Email->bcc(array('brewshop@brewberrys.com','dhrupad.patel@actonate.com'));
                    }

                    $Email->subject($subject);
                    $Email->send($message);

                }

                // Send SMS
                // $sms = new Sms();
                // if($selectedOrder['BillingAddress']['mobile'] != "")
                // {
                //     $sms->sendOrderDispatched($selectedOrder['Order']['code'],$selectedOrder['BillingAddress']['mobile']);
                // }

                // Display success message and redirect
				$this -> Session -> setFlash('New dispatch added.', 'default', array('class' => 'alert alert-success'), 'success');
				$this -> redirect(array('controller' => 'orderdispatches', 'action' => 'index'));

			} else {

				// Display failure message and redirect
                $this -> Session -> setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger'), 'error');
				$this -> redirect(array('controller' => 'orderdispatches', 'action' => 'index'));
			}

		} else {

            // Fetch the order by ID
			$order = $this -> Order -> findById($id);
			$this -> set('order', $order);
			
            // Fetch shipping city by ID
			$shipping = $this -> City -> findById($order['ShippingAddress']['city_id']);
			$this -> set('shipping', $shipping);

			// Fetch billing city by ID
			$billing = $this -> City -> findById($order['BillingAddress']['city_id']);
			$this -> set('billing', $billing);
			
            // Fetch coupon by ID
			$coupon = $this -> Coupon -> findById($order['Order']['coupon_id']);
			$this -> set('coupon', $coupon);

            // Fetch all order items of the order
			$order_items = $this -> OrderItem -> find('all', array('conditions' => array('OrderItem.order_id' => $id,'OrderItem.order_dispatch_id'=>null), 'fields' => array('OrderItem.id', 'Item.name','Item.id','OrderItem.quantity','OrderItem.item_params')));
			$order_items_list = array();

            // Process all the order items into an array with quantity and params, if available for displaying in view.
			foreach ($order_items as $oitem) {
                
                // Create array with order id as the index
                $order_items_list[$oitem['OrderItem']['id']] = array();

                // Check whether variant name is set or not
                if (isset($oitem['Item']['variant_name'])) {

                    // Add variant name to the display name
					$order_items_list[$oitem['OrderItem']['id']]['name'] = $oitem['Item']['name'] . " (" . $oitem['Item']['variant_name'] . ") x ". $oitem['OrderItem']['quantity'];

				} else {

                    // Skip variant name to be added to the display name
					$order_items_list[$oitem['OrderItem']['id']]['name'] = $oitem['Item']['name']. " x ". $oitem['OrderItem']['quantity'];
				}

                // Check whether item parameters are not blank
                if($oitem['OrderItem']['item_params'] != ""){

                    // Add item param to the display params after decoding json
                    $order_items_list[$oitem['OrderItem']['id']]['item_params'] = json_decode($oitem['OrderItem']['item_params'],true);

                } else {

                    // Keep the display params blank
                    $order_items_list[$oitem['OrderItem']['id']]['item_params'] = "";
                }

                // Override the order items array
				$order_items_list[$oitem['OrderItem']['id']]['item_id'] = $oitem['Item']['id'];

			}

            // Fetch all courier in form of list
			$couriers = $this -> Courier -> find('list');
			$this -> set('couriers', $couriers);

            // Set the view variables to controller variable values and layout for the view
            $this -> set('order_items', $order_items_list);
			$this -> set('page_title', 'Create Order Dispatch');
			$this -> layout = 'base_layout';

		}
	}




    
    /*
    // Objective : This function deletes the selected order dispatch
    // Author : Ishan Sheth
    // Last Edit : 28/4/2014
    */
    public function delete($id=null) {

        // Check whether ID is null, if yes - redirect to index
        if($id == null){
            $this->Session->setFlash('Please choose an order disptach.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'orderdispatches', 'action' => 'index'));
        }

        // Fetch the orderdispatch by id
        $selectedItem = $this->OrderDispatch->findById($id);

        // Delete order dispatch
        if($this->OrderDispatch->delete($selectedItem['OrderDispatch']['id'])){

            // Fetch the order for which order dispatch was made
            $selectedOrder = $this->Order->findById($selectedItem['OrderDispatch']['order_id']);

            // Change the order status
            $selectedOrder['Order']['status']=1;

            // Save order
            if($this->Order->save($selectedOrder))
            {

                // Display success message and redirect
                $this->Session->setFlash('Order Dispatch deleted.', 'default', array('class' => 'alert alert-success') , 'success');
                $this -> redirect(array('controller' => 'orderdispatches', 'action' => 'index'));
            
            } else {

                // Display failure message and redirect
                $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'orderdispatches', 'action' => 'index'));
            }

        } else {

            // Display failure message and redirect
            $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'orderdispatches', 'action' => 'index'));
        }
    }


}
?>