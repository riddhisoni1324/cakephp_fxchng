<?php

class PostsController extends AppController {
    var $name = 'Posts';
	var $uses = array('Post','UserCategory','User','Item','ItemStock');
	var $helpers = array('Html','Js', 'Form','Csv','excel');
 
 	public function index()
	{
		$this->layout = 'bgts_main';
	}
 
    public function import() {
        $messages = $this->Post->import('posts.csv');
      //  debug($messages);
      $this->layout = 'bgts_main';
	 $this->redirect(array('controller' => 'Posts', 'action' => 'index'));
    }
	
	function export1() 
	{        
	  $data = $this->Post->find('all',array('fields' => array('Title1','Title2','Title3')));
	  $this->set('alpesh', $data);
	  $this->layout = 'ajax'; 
	}
	function exportDemoRequest()
	{
		if($this->request->is('post'))
		{
			$demo_users = $this->data['demo_user_test'];
			$all_demo_user_details = array();
			foreach ($demo_users as $demo_user) {
				$single_user_data = $this->DemoRequest->findById($demo_user,array('fields' =>'name','email','mobile','city','created'));
			
				if($single_user_data['DemoRequest']['created'] != null && $single_user_data['DemoRequest']['created'] != "")
				{
					$old_date_timestamp = strtotime($single_user_data['DemoRequest']['created']); 
	                $new_date = date('d-m-Y', $old_date_timestamp);
					$single_user_data['DemoRequest']['created'] = $new_date;
				}
				else
				{
					$single_user_data['DemoRequest']['created'] = "";
				}

				
				array_push($all_demo_user_details,$single_user_data);
			}
			
			$this->set('posts',$all_demo_user_details);
			// pr($cat_detail);die();
			$this->layout = null;
			$this->autoLayout = false;
			Configure::write('debug','0');
		}
		else
		{
			$this->Session->setFlash('Sorry,Problem occurrs,try again','default',array('class' =>'alert alert-danger'),'bad');
			$this->redirect(array('controller'=>'users','action'=>'demoRequest'));
		}
		

	}
	function export_stock() 
	{
		//get all items for export data 
		$all_item_lists = $this->ItemStock->find('all',array('fields'=>array('Item.name','ref_no','order_date','delivery_date','expiry_date','discount_price','price','discount_percentage','total_quantity','exhausted_quantity')));	
		
		$all_stock1 = array();
		$item_stock_flag = 1;
		foreach ($all_item_lists as $all_item_list) {
			$all_stock['ItemStock']['Sr.No'] = $item_stock_flag;
			$all_stock['ItemStock']['name'] = $all_item_list['Item']['name'];
			$all_stock['ItemStock']['ref_no'] = $all_item_list['ItemStock']['ref_no'];
			$all_stock['ItemStock']['order_date'] = $all_item_list['ItemStock']['order_date'];

			$all_stock['ItemStock']['delivery_date'] = $all_item_list['ItemStock']['delivery_date'];
			$all_stock['ItemStock']['expiry_date'] = $all_item_list['ItemStock']['expiry_date'];
			$all_stock['ItemStock']['discount_price'] = $all_item_list['ItemStock']['discount_price'];
			$all_stock['ItemStock']['price'] = $all_item_list['ItemStock']['price'];
			$all_stock['ItemStock']['discount_percentage'] = $all_item_list['ItemStock']['discount_percentage'];
			$all_stock['ItemStock']['total_quantity'] = $all_item_list['ItemStock']['total_quantity'];
			$all_stock['ItemStock']['exhausted_quantity'] = $all_item_list['ItemStock']['exhausted_quantity'];
			
			array_push($all_stock1, $all_stock);

			$item_stock_flag++;

		}

		$this->set('posts',$all_stock1);
		// pr($cat_detail);die();
	    $this->layout = null;
	    $this->autoLayout = false;
	    Configure::write('debug','0');
	}
	
	function export() 
	{
		
		//get all items for export data 
		//$all_item_lists = $this->Item->find('all',array('fields'=>array('name','stock_type','featured','item_viewed','franchise_only','vat_percent','cst_percent','cst_cform_percent','Item.item_category_id')));	
		$all_item_lists = $this->Item->find('all');	
		$all_items = array();
		$item_flag=1;
	   foreach ($all_item_lists as $all_item_list) {

	   	$all_item['Item']['Sr.No'] = $item_flag;
	   	$all_item['Item']['name'] = $all_item_list['Item']['name'];

	   	//set value to stock type
	   	if($all_item_list['Item']['stock_type'] == 0)
	   	{
	   		$all_item['Item']['stock_type'] = 'Limited';
	   	}
	   	else
	   	{
	   		$all_item['Item']['stock_type'] = 'Unlimited';
	   	}

	   	//set value to featured
	   	if($all_item_list['Item']['featured'] == 1)
	   	{
	   		$all_item['Item']['featured'] = 'Featured';
	   	}
	   	else
	   	{
	   		$all_item['Item']['featured'] = '';
	   	}

	   	// $all_item['Item']['short_desc'] = $all_item_list['Item']['short_desc'];
	   	// $all_item['Item']['long_desc'] = $all_item_list['Item']['long_desc'];
	   	$all_item['Item']['item_viewed'] = $all_item_list['Item']['item_viewed'];
	   	$all_item['Item']['category'] = $all_item_list['ItemCategory']['name'];
	   	//set value to franchise
	   	if($all_item_list['Item']['franchise_only'] == 1)
	   	{
	   		$all_item['Item']['franchise_only'] = 'Franchise';
	   	}
	   	else
	   	{
	   		$all_item['Item']['franchise_only'] = '';
	   	}
	   	
	   	$all_item['Item']['vat_percent'] = $all_item_list['Item']['vat_percent'];
	   	$all_item['Item']['cst_percent'] = $all_item_list['Item']['cst_percent'];
	   	$all_item['Item']['cst_cform_percent'] = $all_item_list['Item']['cst_cform_percent'];

	   	if($all_item_list['Item']['stock_type'] == 0)
	   	{
	   		$all_stocks=$all_item_list['ItemStock'];
	   		foreach ($all_stocks as $all_stock) {
		   		if($all_stock['exhausted_quantity'] >= $all_stock['total_quantity'])
		   		{
		   			$all_item['Item']['total_quantity'] = '';
		   			$all_item['Item']['exhausted_quantity'] = '';
		   			$all_item['Item']['price'] = '';
		   			$all_item['Item']['discount_price'] = '';


		   		}
		   		else
		   		{
		   			$all_item['Item']['total_quantity'] = $all_stock['total_quantity'];
		   			$all_item['Item']['exhausted_quantity'] = $all_stock['exhausted_quantity'];
		   			$all_item['Item']['price'] = $all_stock['price'];
		   			$all_item['Item']['discount_price'] = $all_stock['discount_price'];	
		   		}
		   	}
	   	}
	   	else
	   	{
	   		$all_item['Item']['total_quantity'] = $all_item_list['ItemStock'][0]['total_quantity'];
		   	$all_item['Item']['exhausted_quantity'] = $all_item_list['ItemStock'][0]['exhausted_quantity'];
	   		$all_item['Item']['price'] = $all_item_list['ItemStock'][0]['price'];
		   	$all_item['Item']['discount_price'] = $all_item_list['ItemStock'][0]['discount_price'];
		}
		$item_flag++;

   		//push to array
   		array_push($all_items, $all_item);
	   }
	    $this->set('posts',$all_items);
		// pr($cat_detail);die();
	    $this->layout = null;
	    $this->autoLayout = false;
	    Configure::write('debug','0');
				
		
	}
	
	public function print_to_excel($id = null) 
	{
	    set_time_limit(120);
	    // $result = $this->SomeModel->printExcel($id);
	    $result = $this->UserCategory->printExcel();
	
	    if (is_array($result)){
	        $filename = key($result);
	        $this->redirect('/outputfiles/Excel/' . $id . '/' . $filename);
	    }
	}
	
	public function export_upload()
	{
		if($this->request->is('post'))
		{
			$file_name = $this->data['Post']['path']['name'];
			move_uploaded_file($this->data['Post']['path']['tmp_name'], TMP.'uploads'.DS.'Post'.DS.$file_name);
			$messages = $this->Post->import($file_name);
	      	$this->layout = 'bgts_main';
		  	$this->redirect(array('controller' => 'Posts', 'action' => 'index'));
		}
	}

	public function testSMS()
	{
		//Send SMS
		$sms_setting = $this->MessageSettings->find('first');

	   $username = $sms_setting['MessageSettings']['username'];
	   $username_v = $sms_setting['MessageSettings']['username_var'];
	   $password = $sms_setting['MessageSettings']['password'];
	   $password_v = $sms_setting['MessageSettings']['password_var'];
	   $senderID = $sms_setting['MessageSettings']['sender'];
	   $senderID_v = $sms_setting['MessageSettings']['sender_var'];
	   $url = $sms_setting['MessageSettings']['api'];
	   $url_file = $sms_setting['MessageSettings']['api_file'];
	   $msg_v = $sms_setting['MessageSettings']['message'];
	   $to_v = $sms_setting['MessageSettings']['mobile'];

       	$demo_sms = new Sms($username,$username_v,$password,$password_v,$senderID,$senderID_v,$msg_v,$url,$url_file,$to_v); 
		
		$sent_sms = $demo_sms->sendVendorReminder("9624138713","Test SMS");
		if($sent_sms) 
		{
			$increment_sms_counter = array();
			$increment_sms_counter['MessageSettings']['id'] = $sms_setting['MessageSettings']['id'];
			$increment_sms_counter['MessageSettings']['sms_counter'] = $sms_setting['MessageSettings']['sms_counter'] + 1;
			$this->MessageSettings->save($increment_sms_counter);
		}
	}
}



// class PostsController extends AppController
// {
	// var $uses = array('UserCategory');
	// var $helpers = array('Html','Js', 'Form','Csv');
// 	
	// public function index()
	// {
		// $this->layout = 'bgts_main';
	// }
// 	
	// function export() 
	// {
// 	
		// $cat_detail = $this->UserCategory->find('all');
	    // // $this->set('posts', $this->UserCategory->find('all'));
	    // $this->set('posts',$cat_detail);
		// // pr($cat_detail);die();
	    // $this->layout = null;
	    // $this->autoLayout = false;
	    // Configure::write('debug','0');
	// }
// 	
// }


?>