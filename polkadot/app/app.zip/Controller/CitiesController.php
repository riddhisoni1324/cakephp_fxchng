<?php
class CitiesController extends AppController {

	public $name = 'Cities';
	public $uses = array('City', 'State');





    /*
    // Objective : This function displays all the cities
    // Author : Ishan Sheth
    // Last Edit : 25/4/2014
    */      
	public function index() {

        // Find all cities
		$cities = $this -> City -> find('all',array('order'=>array('City.name')));
		$this -> set('cities', $cities);

        // Set the view variables to controller variable values and layout for the view
		$this -> set('page_title', 'Cities');
		$this -> layout = 'polka_shell';
	}





    /*
    // Objective : This function adds the city manually
    // Author : Ishan Sheth
    // Last Edit : 25/4/2014
    */    
	public function add() {

        // Check whether it is a post request or not
		if ($this -> request -> is('post')) {

            // Get the data from post request
			$city = $this -> request -> data;

            // Set null values to null allowed columns and respective preprocessing to data before saving data
            if($city['City']['shipping_handling_charges']==""){
                $city['City']['shipping_handling_charges']="";
            }
            $city['City']['name'] = ucfirst($city['City']['name']);

            // Display failure message and redirect
            if(strlen($city['City']['name'])<3) {
                $this->Session->setFlash('Min 3 characters in City Name', 'default', array('class' => 'alert alert-danger') , 'error');
                $this->redirect($this->referer());
            }

            // Set respective preprocessing to data before saving data            
            $city['City']['code'] = $city['City']['name'][0] . $city['City']['name'][1] . $city['City']['name'][2];
            $city['City']['code'] = strtoupper($city['City']['code']);

            // Add city
			if ($this -> City -> save($city)) {

				// Display success message and redirect
                $this->Session->setFlash('New city added.', 'default', array('class' => 'alert alert-success') , 'success');
				$this -> redirect(array('controller' => 'cities', 'action' => 'index'));
			} else {

				// Display failure message and redirect
                $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
				$this -> redirect(array('controller' => 'cities', 'action' => 'index'));
			}

		} else {

            // Get all states
            $states = $this->State->find('list',array('order'=>array('State.name')));
            $this->set('states',$states);
        }

        // Set the view variables to controller variable values and layout for the view
        $this -> set('page_title', 'Add City');
        $this -> layout = 'polka_shell';
	}




    
    /*
    // Objective : This function saves the edited city
    // Author : Ishan Sheth
    // Last Edit : 25/4/2014
    */
    public function edit($id=null) {

        // Check whether it is a post request or not
        if ($this -> request -> is('post')) {

            // Get the data from post request
            $city = $this -> request -> data;

            // Set null values to null allowed columns and respective preprocessing to data before saving data
            if($city['City']['shipping_handling_charges']==""){
                $city['City']['shipping_handling_charges']="";
            }
            $city['City']['name'] = ucfirst($city['City']['name']);

            // Display failure message and redirect
            if(strlen($city['City']['name'])<3){
                $this->Session->setFlash('Min 3 characters in City Name', 'default', array('class' => 'alert alert-danger') , 'error');
                $this->redirect($this->referer());
            }

            // Set respective preprocessing to data before saving data   
            $city['City']['code'] = $city['City']['name'][0] . $city['City']['name'][1] . $city['City']['name'][2];
            $city['City']['code'] = strtoupper($city['City']['code']);

            // Save city
            if ($this -> City -> save($city)) {
                
                // Display success message and redirect
                $this->Session->setFlash('Selected city edited.', 'default', array('class' => 'alert alert-success') , 'success');
                $this -> redirect(array('controller' => 'cities', 'action' => 'index'));
            } else {
                
                // Display failure message and redirect
                $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'cities', 'action' => 'index'));
            }

        } else {

            // Check whether ID is null, if yes - redirect to index
            if($id == null){
                $this->Session->setFlash('Please choose a city.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'cities', 'action' => 'index'));
            }

            // Fetch the city by id
            $selectedCity = $this->City->findById($id);

            // Check whether resultset is null, if yes - redirect to index
            if($selectedCity == null){
                $this->Session->setFlash('Please choose a city.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'cities', 'action' => 'index'));
            }

            // Get all states
            $states = $this->State->find('list',array('order'=>array('State.name')));
            $this->set('states',$states);            

            // Set the view variables to controller variable values and layout for the view
            $this->set('selectedCity',$selectedCity);
            $this -> set('page_title', 'Edit City');
            $this -> layout = 'polka_shell';

        }
    }





    /*
    // Objective : This function deletes the selected city
    // Author : Ishan Sheth
    // Last Edit : 25/4/2014
    */  
    public function delete($id=null) {

        // Check whether ID is null, if yes - set error message and redirect
        if($id == null) {
            $this->Session->setFlash('Please choose a city.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'cities', 'action' => 'index'));
        }

        // Find the selected city
        $selectedCity = $this->City->findById($id);

        // Check whether resultset is null, if yes - set error message and redirect
        if($selectedCity == null){
            $this->Session->setFlash('Please choose a city.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'cities', 'action' => 'index'));
        }

        // Delete city
        if($this->City->delete($selectedCity['City']['id'])){

            // Display success message and redirect
            $this->Session->setFlash('City deleted.', 'default', array('class' => 'alert alert-success') , 'success');
            $this -> redirect(array('controller' => 'cities', 'action' => 'index'));
        
        } else {

            // Display failure message and redirect
            $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'cities', 'action' => 'index'));
        }

        // Set the view variables to controller variable values and layout for the view
        $this -> set('page_title', 'Edit City');
        $this -> layout = 'polka_shell';
    }





    /*
    // Objective : This function toggles the enabled city flag
    // Author : Ishan Sheth
    // Last Edit : 25/4/2014
    */ 
    public function toggle_disable($id=null) {

        // Check whether ID is null, if yes - set error message and redirect
        if ($id == null) {
            
            // Display failure message and redirect
            $this->Session->setFlash('You must select a city.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'cities', 'action' => 'index'));    

        } else {
            
            // Find the city
            $city = $this->City->findById($id);
            
            // Toggle the enabled flag
            if($city['City']['disabled']==0) {

                $city['City']['disabled'] = 1;

            } else {

                $city['City']['disabled'] = 0;

            }
            
            // Save the toggle edit
            if ($this -> City -> save($city)) {
                
                // Display success message and redirect
                $this->Session->setFlash('Selected city updated.', 'default', array('class' => 'alert alert-success') , 'success');
                $this -> redirect(array('controller' => 'cities', 'action' => 'index'));
            } else {
                
                // Display failure message and redirect
                $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'cities', 'action' => 'index'));
            }       
        }
        
        // Set the view variables to controller variable values and layout for the view
        $this -> set('page_title', 'Toggle City Diabled');
        $this -> layout = 'polka_shell';
    }

}
