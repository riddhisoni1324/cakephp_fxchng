<?php
class EmailTemplatesController extends AppController {

    public $name = 'EmailTemplates';
    public $uses = array('EmailTemplate');





    /*
    // Objective : This function displays all the email templates
    // Author : Ishan Sheth
    // Last Edit : 11/8/2014
    */
    public function index() {

        // Get all email templates
        $emails = $this -> EmailTemplate-> find('all',array('order'=>array('EmailTemplate.title')));
        $this -> set('email_templates', $emails);

        // Set the view variables to controller variable values and layout for the view
        $this -> set('page_title', 'View Email Templates');
        $this -> layout = 'base_layout';
    }




    
    /*
    // Objective : This function adds the email template
    // Author : Ishan Sheth
    // Last Edit : 12/8/2014
    */
    public function add() {

        // Check whether it is a post request or not
        if ($this -> request -> is('post')) {

            // Get the data from post request
            $email = $this -> request -> data;

            // Respective preprocessing before saving the data            
            $email['EmailTemplate']['content'] = htmlentities($email['EmailTemplate']['content']);

            // Add email template
            if ($this -> EmailTemplate -> save($email)) {

                // Display success message and redirect
                $this->Session->setFlash('New email added.', 'default', array('class' => 'alert alert-success') , 'success');
                $this -> redirect(array('controller' => 'email_templates', 'action' => 'index'));

            } else {

                // Display failure message and redirect
                $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'email_templates', 'action' => 'index'));
            }

        } else {

        }

        // Set the view variables to controller variable values and layout for the view
        $this -> set('page_title', 'Add Email Template');
        $this -> layout = 'base_layout';
    }




    
    /*
    // Objective : This function saves the edited email template
    // Author : Ishan Sheth
    // Last Edit : 12/8/2014
    */
    public function edit($id) {

        // Check whether it is a post request or not
        if ($this -> request -> is('post')) {

            // Get the data from post request
            $email = $this -> request -> data;

            // Respective preprocessing before saving the data    
            $email['EmailTemplate']['content'] = htmlentities($email['EmailTemplate']['content']);

            // Save email template
            if ($this -> EmailTemplate -> save($email)) {

                // Display success message and redirect
                $this->Session->setFlash('Email Template has been edited.', 'default', array('class' => 'alert alert-success') , 'success');
                $this -> redirect(array('controller' => 'email_templates', 'action' => 'index'));

            } else {

                // Display failure message and redirect
                $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'email_templates', 'action' => 'index'));
            }

        } else {

            // Check whether ID is null, if yes - redirect to index
            if($id == null)
            {
                $this->Session->setFlash('Email Template does not exist.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'email_templates', 'action' => 'index'));
            }

            // Fetch the email template by id
            $selectedEmailTemplate = $this->EmailTemplate->findById($id);

            // Check whether resultset is null, if yes - redirect to index
            if($selectedEmailTemplate == null)
            {
                $this->Session->setFlash('Email Template does not exist.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'email_templates', 'action' => 'index'));
            }

            // Set the view variables to controller variable values
            $this->set('selectedEmailTemplate',$selectedEmailTemplate);

        }

        // Set the view variables to controller variable values and layout for the view
        $this -> set('page_title', 'Edit Email Template');
        $this -> layout = 'base_layout';
    }





    /*
    // Objective : This function deletes the selected email template
    // Author : Ishan Sheth
    // Last Edit : 25/4/2014
    */
    public function delete($id=null) {

        // Check whether ID is null, if yes - set error message and redirect
        if($id == null){
            $this->Session->setFlash('Please choose an email.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'email_templates', 'action' => 'index'));
        }

        // Find the selected email template
        $selectedEmailTemplate = $this->EmailTemplate->findById($id);

        // Check whether resultset is null, if yes - set error message and redirect
        if($selectedEmailTemplate == null){
            $this->Session->setFlash('Please choose an email.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'email_templates', 'action' => 'index'));
        }

        // Delete email template
        if($this->EmailTemplate->delete($selectedEmailTemplate['EmailTemplate']['id'])){

            // Display success message and redirect
            $this->Session->setFlash('EmailTemplate deleted.', 'default', array('class' => 'alert alert-success') , 'success');
            $this -> redirect(array('controller' => 'email_templates', 'action' => 'index'));

        } else {

            // Display failure message and redirect
            $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'email_templates', 'action' => 'index'));
        }

        // Set the view variables to controller variable values and layout for the view
        $this -> set('page_title', 'Delete Email Template');
        $this -> layout = 'polka_shell';
    }


}
?>
