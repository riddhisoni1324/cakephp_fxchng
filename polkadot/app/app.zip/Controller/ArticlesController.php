<?php
class ArticlesController extends AppController {

    public $name = 'Articles';
    public $uses = array('Article');




    
    /*
    // Objective : This function displays all the articles
    // Author : Ishan Sheth
    // Last Edit : 11/8/2014
    */   
    public function index() {

        // Get all articles
        $articles = $this -> Article-> find('all',array('order'=>array('Article.title')));
        $this -> set('articles', $articles);

        // Set the view variables to controller variable values and layout for the view
        $this -> set('page_title', 'View Articles');
        $this -> layout = 'base_layout';
    }




    
    /*
    // Objective : This function adds an article
    // Author : Ishan Sheth
    // Last Edit : 11/8/2014
    */ 
    public function add() {

        // Check whether the request is a post request
        if ($this -> request -> is('post')) {

            // Get the data from post request 
            $article = $this -> request -> data;

            // Set respective preprocessing to data before saving data
            $article['Article']['content'] = htmlentities($article['Article']['content']);
            $article['Article']['alias'] = str_replace(" ","_",strtolower($article['Article']['title']));

            // Add article
            if ($this -> Article -> save($article)) {

                // Display success message and redirect
                $this->Session->setFlash('New article added.', 'default', array('class' => 'alert alert-success') , 'success');
                $this -> redirect(array('controller' => 'articles', 'action' => 'index'));
            } else {

                // Display failure message and redirect
                $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'articles', 'action' => 'index'));
            }

        } 

        // Set the view variables to controller variable values and layout for the view
        $this -> set('page_title', 'Add Article');
        $this -> layout = 'base_layout';
    }




    
    /*
    // Objective : This function displays all the item categories
    // Author : Ishan Sheth
    // Last Edit : 11/8/2014
    */ 
    public function edit($id) {

        // Check whether the request is a post request
        if ($this -> request -> is('post')) {

            // Get the data from post request
            $article = $this -> request -> data;

            // Set respective preprocessing to data before saving data
            $article['Article']['content'] = htmlentities($article['Article']['content']);
            $article['Article']['alias'] = str_replace(" ","_",strtolower($article['Article']['title']));

            // Save article
            if ($this -> Article -> save($article)) {

                // Display success message and redirect
                $this->Session->setFlash('Article has been edited.', 'default', array('class' => 'alert alert-success') , 'success');
                $this -> redirect(array('controller' => 'articles', 'action' => 'index'));

            } else {

                // Display failure message and redirect
                $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'articles', 'action' => 'index'));
            }

        } else {

            // Check whether id is null, if yes - display failure message and redirect
            if($id == null) {

                // Display failure message and redirect
                $this->Session->setFlash('Article does not exist.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'articles', 'action' => 'index'));
            }

            // Fetch the item article by id
            $selectedArticle = $this->Article->findById($id);

            // Check whether resultset is null, if yes - display failure message and redirect
            if($selectedArticle == null) {

                // Display failure message and redirect
                $this->Session->setFlash('Article does not exist.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'articles', 'action' => 'index'));
            }

            // Set the view variables to controller variable values
            $this->set('selectedArticle',$selectedArticle);

        }

        // Set the view variables to controller variable values and layout for the view
        $this -> set('page_title', 'Edit Article');
        $this -> layout = 'base_layout';
    }




    
    /*
    // Objective : This function deletes the selected article
    // Author : Ishan Sheth
    // Last Edit : 24/4/2014
    */
    public function delete($id=null) {

        // Check whether ID is null, if yes - redirect to index
        if($id == null) {

            // Display failure message and redirect
            $this->Session->setFlash('Please choose an article.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'articles', 'action' => 'index'));
        }

        // Fetch the item article by id
        $selectedArticle = $this->Article->findById($id);

        // Check whether ID is null, if yes - redirect to index
        if($selectedArticle == null){

            // Display failure message and redirect
            $this->Session->setFlash('Please choose an article.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'articles', 'action' => 'index'));
        }

        // Delete selected article
        if($this->Article->delete($selectedArticle['Article']['id'])){

            // Display success message and redirect
            $this->Session->setFlash('Article deleted.', 'default', array('class' => 'alert alert-success') , 'success');
            $this -> redirect(array('controller' => 'articles', 'action' => 'index'));

        } else {

            // Display failure message and redirect
            $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'articles', 'action' => 'index'));

        }

    }


}
