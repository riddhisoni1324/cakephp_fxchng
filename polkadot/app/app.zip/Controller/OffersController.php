<?php
class OffersController extends AppController {

    public $name = 'Offers';
    public $uses = array('Offer', 'State');




    
    /*
    // Objective : This function displays all the offers
    // Author : Ishan Sheth
    // Last Edit : 11/8/2014
    */
    public function index() {

        // Get all the offers ordered by created date time
        $offers = $this -> Offer -> find('all',array('order'=>array('Offer.created')));
        $this -> set('offers', $offers);

        // Set the view variables to controller variable values and layout for the view
        $this -> set('page_title', 'View Offers');
        $this -> layout = 'base_layout';
    }




    
    /*
    // Objective : This function adds the offer
    // Author : Ishan Sheth
    // Last Edit : 11/8/2014
    */
    public function add() {

        // Check whether it is a post request or not
        if ($this -> request -> is('post')) {
            $offer = $this -> request -> data;

            // Add offer
            if ($this -> Offer -> save($offer)) {

                // Display success message and redirect
                $this->Session->setFlash('New offer added.', 'default', array('class' => 'alert alert-success') , 'success');
                $this -> redirect(array('controller' => 'offers', 'action' => 'index'));

            } else {
                
                // Display failure message and redirect
                $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'offers', 'action' => 'index'));

            }

        } else {

        }

        // Set the view variables to controller variable values and layout for the view
        $this -> set('page_title', 'Add Offer');
        $this -> layout = 'base_layout';
    }




    
    /*
    // Objective : This function saves the edited offer
    // Author : Ishan Sheth
    // Last Edit : 11/8/2014
    */
    public function edit($id=null) {

        // Check whether it is a post request or not
        if ($this -> request -> is('post')) {

            // Get the data from post request
            $offer = $this -> request -> data;

            // Save offer
            if ($this -> Offer -> save($offer)) {

                // Display success message and redirect
                $this->Session->setFlash('Selected offer edited.', 'default', array('class' => 'alert alert-success') , 'success');
                $this -> redirect(array('controller' => 'offers', 'action' => 'index'));

            } else {

                // Display failure message and redirect
                $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'offers', 'action' => 'index'));
            }
        
        } else {

            // Check whether ID is null, if yes - redirect to index
            if($id == null){
                $this->Session->setFlash('Please choose a offer.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'offers', 'action' => 'index'));
            }

            // Fetch the item category by id
            $selectedOffer = $this->Offer->findById($id);

            // Check whether resultset is null, if yes - redirect to index
            if($selectedOffer == null){
                $this->Session->setFlash('Please choose a offer.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'offers', 'action' => 'index'));
            }

            // Set the view variables to controller variable values and layout for the view
            $this->set('offer',$selectedOffer);
            $this -> set('page_title', 'Edit Offer');
            $this -> layout = 'base_layout';

        }
    }




    
    /*
    // Objective : This function deletes the selected offer
    // Author : Ishan Sheth
    // Last Edit : 22/4/2014
    */
    public function delete($id=null) {

        
        // Check whether ID is null, if yes - redirect to index
        if($id == null){
            $this->Session->setFlash('Please choose a offer.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'offers', 'action' => 'index'));
        }

        // Fetch offer by ID
        $selectedOffer = $this->Offer->findById($id);

        // Check whether resultset is null, if yes - redirect to index
        if($selectedOffer == null){
            $this->Session->setFlash('Please choose a offer.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'offers', 'action' => 'index'));
        }

        // Delete offer
        if($this->Offer->delete($selectedOffer['Offer']['id'])){

            // Display success message and redirect
            $this->Session->setFlash('Offer deleted.', 'default', array('class' => 'alert alert-success') , 'success');
            $this -> redirect(array('controller' => 'offers', 'action' => 'index'));

        } else {

            // Display failure message and redirect
            $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'offers', 'action' => 'index'));

        }

        // Set the view variables to controller variable values and layout for the view
        $this -> set('page_title', 'Edit Offer');
        $this -> layout = 'polka_shell';
    }


}
?>