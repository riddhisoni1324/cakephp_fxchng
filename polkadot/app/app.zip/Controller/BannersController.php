<?php
class BannersController extends AppController {

    public $name = 'Banners';
    public $uses = array('Banner', 'State','City','BannerCity');





    /*
    // Objective : This function displays all the banners
    // Author : Ishan Sheth
    // Last Edit : 11/8/2014
    */      
    public function index() {

        // Get all banners
        $banners = $this -> Banner -> find('all',array('order'=>array('Banner.caption')));
        $this -> set('banners', $banners);

        // Set the view variables to controller variable values and layout for the view
        $this -> set('page_title', 'View Banners');
        $this -> layout = 'base_layout';
    }




    
    /*
    // Objective : This function adds the banner
    // Author : Ishan Sheth
    // Last Edit : 11/8/2014
    */       
    public function add() {

        // Check whether it is a post request or not
        if ($this -> request -> is('post')) {

            // Get the data from post request
            $banner = $this -> request -> data;

            // Add banner
            if ($this -> Banner -> save($banner)) {		
			
                // Display success message and redirect
                $this->Session->setFlash('New banner added.', 'default', array('class' => 'alert alert-success') , 'success');
                $this -> redirect(array('controller' => 'banners', 'action' => 'index'));

            } else {

                // Display failure message and redirect
                $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'banners', 'action' => 'index'));
            }

        } else {

            // Set options for position
			$position = array('left-bottom'=>'left-bottom', 'left-top'=>'left-top','right-bottom'=>'right-bottom','right-top'=>'right-top');
            $this -> set('position', $position);
		
        }

        // Set the view variables to controller variable values and layout for the view
        $this -> set('page_title', 'Add Banner');
        $this -> layout = 'base_layout';
    }




    
    /*
    // Objective : This function saves the edited banner
    // Author : Ishan Sheth
    // Last Edit : 11/8/2014
    */
    public function edit($id=null) {

        // Check whether it is a post request or not
        if ($this -> request -> is('post')) {

            // Get the data from post request
            $banner = $this -> request -> data;

            // Save banner
            if ($this -> Banner -> save($banner)) {	
				
                // Display success message and redirect
                $this->Session->setFlash('Selected banner edited.', 'default', array('class' => 'alert alert-success') , 'success');
                $this -> redirect(array('controller' => 'banners', 'action' => 'index'));
            } else {

                // Display failure message and redirect
                $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'banners', 'action' => 'index'));
            }

        } else {

            // Check whether ID is null, if yes - redirect to index
            if($id == null){
                $this->Session->setFlash('Please choose a banner.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'banners', 'action' => 'index'));
            }

            // Fetch the banner by id
            $selectedBanner = $this->Banner->findById($id);

            // Check whether resultset is null, if yes - redirect to index
            if($selectedBanner == null){
                $this->Session->setFlash('Please choose a banner.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'banners', 'action' => 'index'));
            }		
			
            // Set the position options
			$position = array('left-bottom'=>'left-bottom', 'left-top'=>'left-top','right-bottom'=>'right-bottom','right-top'=>'right-top');
            $this -> set('position', $position);			
			
            // Set the view variables to controller variable values and layout for the view
            $this->set('banner',$selectedBanner);
            $this -> set('page_title', 'Edit Banner');
            $this -> layout = 'base_layout';

        }
    }





    /*
    // Objective : This function deletes the selected banner
    // Author : Ishan Sheth
    // Last Edit : 24/4/2014
    */ 
    public function delete($id=null) {

        // Check whether ID is null, if yes - set error message and redirect
        if($id == null){
            $this->Session->setFlash('Please choose a banner.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'banners', 'action' => 'index'));
        }

        // Find the selected banner
        $selectedBanner = $this->Banner->findById($id);

        // Check whether resultset is null, if yes - set error message and redirect
        if($selectedBanner == null){
            $this->Session->setFlash('Please choose a banner.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'banners', 'action' => 'index'));
        }

        // Delete banner
        if($this->Banner->delete($selectedBanner['Banner']['id'])){

            // Display success message and redirect
            $this->Session->setFlash('Banner deleted.', 'default', array('class' => 'alert alert-success') , 'success');
            $this -> redirect(array('controller' => 'banners', 'action' => 'index'));
        
        } else {

            // Display failure message and redirect
            $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'banners', 'action' => 'index'));
        }

        // Set the view variables to controller variable values and layout for the view
        $this -> set('page_title', 'Delete Banner');
        $this -> layout = 'polka_shell';
    }


}
?>
