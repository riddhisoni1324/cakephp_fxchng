<?php
class SmsTemplatesController extends AppController {

    public $name = 'SmsTemplates';
    public $uses = array('SmsTemplate');





    /*
    // Objective : This function displays all the sms templates
    // Author : Ishan Sheth
    // Last Edit : 12/8/2014
    */   
    public function index() {

        // Get all sms templates
        $sms_templates = $this -> SmsTemplate-> find('all',array('order'=>array('SmsTemplate.title')));
        $this -> set('sms_templates', $sms_templates);

        // Set the view variables to controller variable values and layout for the view
        $this -> set('page_title', 'View SMS Templates');
        $this -> layout = 'base_layout';
    }




    
    /*
    // Objective : This function adds the sms template
    // Author : Ishan Sheth
    // Last Edit : 12/8/2014
    */     
    public function add() {

        // Check whether it is a post request or not
        if ($this -> request -> is('post')) {

            // Get the data from post request
            $sms_template = $this -> request -> data;

            // Set null values to null allowed columns and respective preprocessing to data before saving data
            $sms_template['SmsTemplate']['content'] = htmlentities($sms_template['SmsTemplate']['content']);
            $sms_template['SmsTemplate']['alias'] = str_replace(" ","_",strtolower($sms_template['SmsTemplate']['title']));

            // Add sms template
            if ($this -> SmsTemplate -> save($sms_template)) {

                // Display success message and redirect
                $this->Session->setFlash('New SMS Template added.', 'default', array('class' => 'alert alert-success') , 'success');
                $this -> redirect(array('controller' => 'sms_templates', 'action' => 'index'));
            
            } else {

                // Display failure message and redirect
                $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'sms_templates', 'action' => 'index'));
            }

        } else {

        }

        // Set the view variables to controller variable values and layout for the view
        $this -> set('page_title', 'Add SMS Template');
        $this -> layout = 'base_layout';
    }





    /*
    // Objective : This function saves the selected sms template
    // Author : Ishan Sheth
    // Last Edit : 12/8/2014
    */  
    public function edit($id) {

        // Check whether ID is null, if yes - set error message and redirect
        if ($this -> request -> is('post')) {

            // Find the selected item
            $sms_template = $this -> request -> data;

            // Respective preprocessing before saving the data
            $sms_template['SmsTemplate']['content'] = htmlentities($sms_template['SmsTemplate']['content']);
            $sms_template['SmsTemplate']['alias'] = str_replace(" ","_",strtolower($sms_template['SmsTemplate']['title']));

            // Save sms template
            if ($this -> SmsTemplate -> save($sms_template)) {

                // Display success message and redirect
                $this->Session->setFlash('Sms Template has been edited.', 'default', array('class' => 'alert alert-success') , 'success');
                $this -> redirect(array('controller' => 'sms_templates', 'action' => 'index'));

            } else {

                // Display failure message and redirect
                $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'sms_templates', 'action' => 'index'));
            }

        } else {

            // Check whether ID is null, if yes - redirect to index
            if($id == null)
            {
                $this->Session->setFlash('Sms Template does not exist.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'sms_templates', 'action' => 'index'));
            }

            // Fetch the sms template by id
            $selectedSmsTemplate = $this->SmsTemplate->findById($id);

            // Check whether resultset is null, if yes - redirect to index
            if($selectedSmsTemplate == null)
            {
                $this->Session->setFlash('Sms Template does not exist.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'sms_templates', 'action' => 'index'));
            }
            $this->set('selectedSmsTemplate',$selectedSmsTemplate);
        }

        // Set the view variables to controller variable values and layout for the view
        $this -> set('page_title', 'Edit SMS Template');
        $this -> layout = 'base_layout';
    }





    /*
    // Objective : This function deletes the selected sms template
    // Author : Ishan Sheth
    // Last Edit : 24/4/2014
    */ 
    public function delete($id=null) {

        // Check whether ID is null, if yes - set error message and redirect
        if($id == null){
            $this->Session->setFlash('Please choose an sms template.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'sms_templates', 'action' => 'index'));
        }

        // Find the selected sms template
        $selectedSmsTemplate = $this->SmsTemplate->findById($id);

        // Check whether resultset is null, if yes - set error message and redirect
        if($selectedSmsTemplate == null){
            $this->Session->setFlash('Please choose an sms template.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'sms_templates', 'action' => 'index'));
        }

        // Delete sms template
        if($this->SmsTemplate->delete($selectedSmsTemplate['SmsTemplate']['id'])){

            // Display success message and redirect
            $this->Session->setFlash('SmsTemplate deleted.', 'default', array('class' => 'alert alert-success') , 'success');
            $this -> redirect(array('controller' => 'sms_templates', 'action' => 'index'));

        } else {

            // Display failure message and redirect
            $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'sms_templates', 'action' => 'index'));
        }

        // Set the view variables to controller variable values and layout for the view
        $this -> set('page_title', 'Delete Sms Template');
        $this -> layout = 'polka_shell';
    }


}
