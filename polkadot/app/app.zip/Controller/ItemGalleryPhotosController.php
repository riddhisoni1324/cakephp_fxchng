<?php
class ItemGalleryPhotosController extends AppController {

	public $name = 'ItemGalleryPhotos';
	public $uses = array('Item', 'ItemCategory','ItemStock','City','ItemGalleryPhoto');





    /*
    // Objective : This function adds all the item gallery photos
    // Author : Ishan Sheth
    // Last Edit : 8/8/2014
    */
	public function add($id=null) {

		// Check whether it is a post request or not
		if ($this -> request -> is('post')) {
		
			// Get the data from post request
			$data_packets = $this->request->data;
			$id = $data_packets['ItemGalleryPhoto']['item_id'];

			// Check whether id is null, if yes - redirect to index
			if($id == null){
                $this->Session->setFlash('You must select an item.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect($this->referer());
            }

			// Fetch item details if item id is set
            $selectedItem = $this->Item->findById($id);

			// Check whether resultset is null, if yes - redirect to index
            if($selectedItem == null){
                $this->Session->setFlash('Sorry an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect($this->referer());
            }
            $this->set('selectedItem',$selectedItem);            			
			
			// Set file upload array of the files which are uploaded
			$filenames = array();
			foreach($data_packets['ItemGalleryPhoto']['file_names'] as $key=>$value){
				$filename = array();
				$filename['item_id'] = $id;
				$filename['file_name']['name'] = $value['name'];
				$filename['file_name']['type'] = $value['type'];
				$filename['file_name']['tmp_name'] = $value['tmp_name'];
				$filename['file_name']['size'] = $value['size'];
				$filename['file_name']['error'] = $value['error'];
				$filename['featured'] = 0;
				$filename['model'] = 'ItemGalleryPhoto';
				
				array_push($filenames, $filename);
			}			
			
			// Here is the upload handler for the uploaded files
			if($this->ItemGalleryPhoto->saveMany($filenames)) {
				$this->Session->setFlash('Item gallery photo/s added.', 'default', array('class' => 'alert alert-success') , 'success');
				$this -> redirect($this->referer());
			} else {
				$this->Session->setFlash('Sorry an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
				$this -> redirect($this->referer());
			}
			
		} else {		
			
		}
	
	}





    /*
    // Objective : This function displays all the items
    // Author : Ishan Sheth
    // Last Edit : 8/8/2014
    */
    public function delete($id=null) {

    	// Check whether ID is null, if yes - redirect to index
        if($id == null){
            $this->Session->setFlash('Please choose an item gallery photo.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this->redirect($this->referer());
        }

        // Fetch the item gallery photo by id
        $selectedItemGP = $this->ItemGalleryPhoto->findById($id);

        // Check whether resultset is null, if yes - redirect to index
        if($selectedItemGP == null){
            $this->Session->setFlash('Please choose an item gallery photo.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this->redirect($this->referer());
        }

        // Delete associated item gallery photo
        if($this->ItemGalleryPhoto->delete($id)){

        	// Display success message and redirect
            $this->Session->setFlash('Item gallery photo deleted.', 'default', array('class' => 'alert alert-success') , 'success');
            $this->redirect($this->referer());

        } else {

        	// Display failure message and redirect
            $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this->redirect($this->referer());
        }
    }		

}
?>