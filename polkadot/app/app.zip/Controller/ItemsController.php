<?php
class ItemsController extends AppController {

	public $name = 'Items';
	public $uses = array('Item', 'ItemCategory','ItemStock','City','ItemGalleryPhoto','UserCategory','BulkItem');
    var $helpers = array('Html','Js', 'Form','Csv','excel');


    /*
    // Objective : This function displays all the items
    // Author : Ishan Sheth
    // Last Edit : 4/8/2014
    */      
	public function index() {

        // we prepare our query, the cakephp way!
        $this->paginate = array(
            'limit' => 10,
            'order' => array('Item.modified' => 'desc')
        );
     
        // we are using the 'Item' model
        $items = $this->paginate('Item');

        // Set the view variables to controller variable values and layout for the view
        $this -> set('items', $items);
        
        $this -> set('page_title', 'View Items');
        $this -> layout = 'base_layout';

        // total entry of item count
        $item_count = $this-> Item ->find('all');
        $item_count1 = sizeof($item_count);
        $this->set('item_count',$item_count1);
	}




    
    /*
    // Objective : This function adds the item
    // Author : Ishan Sheth
    // Last Edit : 4/8/2014
    */        
    public function add() {

        // Check whether it is a post request or not
        if ($this -> request -> is('post')) {

            // Get the data from post request
            $item = $this->request->data;

            // Set item sku code
            $item['Item']['sku_code'] = strtoupper("SKU".uniqid());

            // Set null values to null allowed columns and respective preprocessing to data before saving data
            if($item['Item']['item_id']==""){
                $item['Item']['item_id'] = null;
            }
            if($item['Item']['item_category_id']==""){
                $item['Item']['item_category_id'] = null;
            }
            if($item['Item']['shipping_charges']==""){
                $item['Item']['shipping_charges'] = -1;
            }
            $item['Item']['long_desc'] = htmlentities($item['Item']['long_desc']);
            $discount_percent=0;

            // Processing for items with infinite stock only
            if($item['Item']['stock_type']==1) {

                // Check whether item price is not blank
                if($item['Item']['price']!="") {

                    // If there is no discount price, then set the discounted price to item price
                    if($item['Item']['discount_price']=="") {
                        $item['Item']['discount_price']=$item['Item']['price'];
                    }

                    // Display failure message and redirect
                    if($item['Item']['discount_price']>$item['Item']['price']){
                        $this->Session->setFlash('Discounted price is greater than price.', 'default', array('class' => 'alert alert-danger') , 'error');
                        $this -> redirect(array('controller' => 'items', 'action' => 'add'));
                    }

                    // Calculate discount percentage, if discounted price is entered
                    $discount_percent = round(($item['Item']['price'] - $item['Item']['discount_price'])/$item['Item']['price'],2)*100;
                
                } else {

                    // Display failure message and redirect
                    $this->Session->setFlash('You must set a price.', 'default', array('class' => 'alert alert-danger') , 'error');
                    $this -> redirect(array('controller' => 'items', 'action' => 'add'));
                }
            }

            // Add item
            if ($this->Item ->save($item)) {

                // Get the last insert id of the item which is inserted
                $last_id = $this->Item->getInsertID();

                // Processing for items with infinite stock only, add to stock
                if($item['Item']['stock_type']==1) {

                    $newStock = array();
                    $newStock['ItemStock']['ref_no'] = "IN000".uniqid();
                    $newStock['ItemStock']['item_id'] = $last_id;
                    $newStock['ItemStock']['total_quantity'] = -1;
                    $newStock['ItemStock']['price'] = $item['Item']['price'];
                    $newStock['ItemStock']['discount_price'] = $item['Item']['discount_price'];
                    $newStock['ItemStock']['discount_percentage'] = $discount_percent;
                    $newStock['ItemStock']['vendor_id'] = "53e9c4b2-6c28-4a73-a8c3-3519bf642048";
                    $this->ItemStock->save($newStock);
                }

                // Display success message
                $this->Session->setFlash('New item added.', 'default', array('class' => 'alert alert-success') , 'success');
                
                // Redirect according to stock type
                if($item['Item']['stock_type']==0){

                    // Redirect to add stock for items with limtied stock type
                    $this -> redirect(array('controller' => 'item_stocks', 'action' => 'add',$last_id));
                
                } else {

                    // Redirect to the items listing if item is with infinite stock
                    $this -> redirect(array('controller' => 'items', 'action' => 'add'));
                }
                
            } else {

                // Display failure message and redirect
                $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'items', 'action' => 'add'));
            }

        } else {

            // Get item categories
            $itemCats = $this -> ItemCategory -> find('list', array('order' => 'ItemCategory.name ASC'));
            $this -> set('item_categories', $itemCats);

            // Get parent items
            $itemParentsList = array();
            $this -> set('item_parents', $itemParentsList);

            // Get the items for autofilling
            $autofill = array();
            $this -> set('autofill', $autofill);

            // Set options for stock type, currently only infinite is needed
            $stockType = array(0=>'Limited', 1=>'Infinite');
            //$stockType = array( 1=>'Infinite');
            $this -> set('stock_type', $stockType);

            // Set the view variables to controller variable values and layout for the view
            $this -> set('page_title', 'Add Item');            
            $this -> layout = 'base_layout';
        }
       

    }

    
    /*
    // Objective : This function saves the edited item
    // Author : Ishan Sheth
    // Last Edit : 7/8/2014
    */
    public function edit($id=null) {
        
        // Check whether it is a post request or not
        if ($this -> request -> is('post')) {

            // Get the data from post request
            $item = $this->request->data;
            
            // Set null values to null allowed columns and respective preprocessing to data before saving data
            if($item['Item']['item_id']=="") {
                $item['Item']['item_id'] = null;
            }
            if($item['Item']['item_category_id']=="") {
                $item['Item']['item_category_id'] = null;
            }

            if($item['Item']['shipping_charges']=="") {
                $item['Item']['shipping_charges'] = -1;
            }
            $item['Item']['long_desc'] = htmlentities($item['Item']['long_desc']);
            $discount_percent=0;

            // Processing for items with infinite stock only
            if($item['Item']['stock_type']==1) {

                // Check whether item price is not blank
                if($item['Item']['price']!="") {

                    // If there is not discount price, then set the discounted price to item price
                    if($item['Item']['discount_price']=="") {
                        $item['Item']['discount_price']=$item['Item']['price'];
                    }

                    // Display failure message and redirect
                    if($item['Item']['discount_price']>$item['Item']['price']) {
                        $this->Session->setFlash('Discounted price is greater than price.', 'default', array('class' => 'alert alert-danger') , 'error');
                        $this -> redirect(array('controller' => 'items', 'action' => 'add'));
                    }

                    // Calculate discount percentage, if discounted price is entered
                    $discount_percent = round(($item['Item']['price'] - $item['Item']['discount_price'])/$item['Item']['price'],2)*100;
                
                } else {

                    // Display failure message and redirect
                    $this->Session->setFlash('You must set a price.', 'default', array('class' => 'alert alert-danger') , 'error');
                    $this -> redirect(array('controller' => 'items', 'action' => 'add'));
                }
            }

            // Save item
            if ($this->Item ->save($item)) {

                // Get the last insert id of the item which is inserted
                $last_id = $item['Item']['id'];

                // Processing for items with infinite stock only, add to stock
                if($item['Item']['stock_type']==1){
                    
                    // Find the stock for the item, if present - save the edits or add new item stock
                    $newStock = $this->ItemStock->findByItemId($last_id);
                    if($newStock == null)
                    {
                        $newStock = array();
                        $newStock['ItemStock']['ref_no'] = "IN000".uniqid();
                        $newStock['ItemStock']['item_id'] = $last_id;
                        $newStock['ItemStock']['total_quantity'] = -1;
                        $newStock['ItemStock']['price'] = $item['Item']['price'];
                        $newStock['ItemStock']['discount_price'] = $item['Item']['discount_price'];
                        $newStock['ItemStock']['discount_percentage'] = $discount_percent;
                    } else { 
                        $newStock['ItemStock']['price'] = $item['Item']['price'];
                        $newStock['ItemStock']['discount_price'] = $item['Item']['discount_price'];
                        $newStock['ItemStock']['discount_percentage'] = $discount_percent;
                    }
                    $this->ItemStock->save($newStock);
                }

                // Redirect according to stock type
                if($item['Item']['stock_type']==0){

                    // Display success message & Redirect to add stock for items with limtied stock type
                    $this->Session->setFlash('Item edited.', 'default', array('class' => 'alert alert-success') , 'success');
                    $this -> redirect(array('controller' => 'item_stocks', 'action' => 'index',$last_id));
                
                } else {

                    // Display success message & Redirect to the items listing if item is with infinite stock
                    $this->Session->setFlash('Item edited.', 'default', array('class' => 'alert alert-success') , 'success');
                    $this -> redirect(array('controller' => 'items', 'action' => 'index'));
                }

            } else {

                // Display failure message and redirect
                $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'items', 'action' => 'index'));
            }
        } else {

            // Check whether ID is null, if yes - redirect to index
            if($id == null){
                $this->Session->setFlash('Sorry an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'items', 'action' => 'index'));
            }

            // Fetch the item category by id
            $selectedItem = $this->Item->findById($id);

            // Check whether resultset is null, if yes - redirect to index
            if($selectedItem == null){
                $this->Session->setFlash('Sorry an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'items', 'action' => 'index'));
            }
            $this->set('selectedItem',$selectedItem);

            // Get Item Category 
            $itemCats = $this -> ItemCategory -> find('list', array('order' => 'ItemCategory.name ASC'));
            $this -> set('item_categories', $itemCats);

            // Get parent items
            $itemParentsList = array();
            $this -> set('item_parents', $itemParentsList);

            // Get the items for autofilling
            $autofill = array();
            $this -> set('autofill', $autofill);

            // Set options for stock type, only infinite to limited is allowed not vice versa
            $stockType = array(0=>'Limited', 1=>'Infinite');
            $this -> set('stock_type', $stockType);

            // Set the view variables to controller variable values and layout for the view
            $this -> set('page_title', 'Edit Item');
            $this -> layout = 'base_layout';   

        }

    }





    /*
    // Objective : This function deletes the selected item
    // Author : Ishan Sheth
    // Last Edit : 24/4/2014
    */  
    public function delete($id=null) {

        // Check whether ID is null, if yes - set error message and redirect
        if($id == null){
            $this->Session->setFlash('Please choose an item.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'items', 'action' => 'index'));
        }

        // Find the selected item
        $selectedItem = $this->Item->findById($id);

        // Check whether resultset is null, if yes - set error message and redirect
        if($selectedItem == null){
            $this->Session->setFlash('Please choose an item.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'items', 'action' => 'index'));
        }

        // Delete associated item stock
        $this->ItemStock->deleteAll(array('ItemStock.item_id'=>$selectedItem['Item']['id']));
        if($this->Item->delete($selectedItem['Item']['id'])){

            // Display success message and redirect
            $this->Session->setFlash('Item & Stock deleted.', 'default', array('class' => 'alert alert-success') , 'success');
            $this -> redirect(array('controller' => 'items', 'action' => 'index'));
        } else {

            // Display failure message and redirect
            $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'items', 'action' => 'index'));
        }
    }





    /*
    // Objective : This function shows the item
    // Author : Ishan Sheth
    // Last Edit : 7/8/2014
    */	
    public function viewitem($id=null) {
        if ($this -> request -> is('post')) {

        } else {

            // Check whether ID is null, if yes - redirect to index
            if($id == null) {

                $this->Session->setFlash('Invalid Item.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'items', 'action' => 'index'));
            }

            // Fetch the item category by id
            $selectedItem = $this->Item->findById($id);

            // Check whether ID is null, if yes - redirect to index
            if($selectedItem == null) {

                $this->Session->setFlash('Sorry an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'items', 'action' => 'index'));
            }

            // Set the selected item to variable
            $this->set('selectedItem',$selectedItem);

            // Set stock type
            $stockType = array(0=>'Limited', 1=>'Infinite');
            $this -> set('stock_type', $stockType);

            // Get item gallery photos
            $itemGalleryPhotos = $this -> ItemGalleryPhoto -> find('all', array('conditions' => array('ItemGalleryPhoto.item_id' => $id)));
            $this -> set('itemGalleryPhotos', $itemGalleryPhotos);       

            // Set the view variables to controller variable values and layout for the view
            $this -> set('page_title', 'View Item');
            $this -> layout = 'base_layout';

        }

    }	





    /*
    // Objective : This function shows the item in ajax mode
    // Author : Ishan Sheth
    // Last Edit : 6/8/2014
    */  
    public function json($id=null){

        // Check whether ID is null, if yes - set error message
        if($id == null){
            $this->set('message','error');
        }

        // Find the selected item
        $selectedItem = $this->Item->findById($id);

        // Check whether resultset is null
        if($selectedItem == null) {

            // Set error message
            $this->set('message','error');
        } else {

            if($selectedItem['Item']['item_id'] != null){
                $parent = $this->Item->findById($selectedItem['Item']['item_id']);
                $selectedItem['Item']['item_parents'] = $parent['Item']['name'];
            }            

            // Decode the html entity and set the varible accordingly
            $selectedItem['Item']['long_desc'] = html_entity_decode($selectedItem['Item']['long_desc']);
            $this->set('message',json_encode($selectedItem));
        }

        // Set the layout for the view
        $this->layout = 'ajax_layout';
    }





    /*
    // Objective : This function sets the selected item featured flag
    // Author : Ishan Sheth
    // Last Edit : 9/8/2014
    */ 
    public function set_featured_ajax($id=null) {

        // Find the selected item
        $selectedItem = $this->Item->findById($id);
        $return_message = ""; 
        
        // Set the featured flag to true
        $selectedItem['Item']['featured']=1;

        // Save the item
        if($this->Item->save($selectedItem)) {

            //This flash message has to be set in the view properly
            $return_message =  "Done.";
        } else {

            //This flash message has to be set in the view properly
            $return_message =  "Sorry an error occurred.";
        }

        // Set the view variables to controller variable values and layout for the view
        $this->set('return_message',$return_message);
        $this -> layout = 'ajax';        
    }





    /*
    // Objective : This function unsets the selected item featured flag
    // Author : Ishan Sheth
    // Last Edit : 9/8/2014
    */ 
    public function unset_featured_ajax($id=null) {

        // Find the selected item
        $selectedItem = $this->Item->findById($id);
        $return_message = ""; 
        
        // Set the featured flag to true
        $selectedItem['Item']['featured']=0;

        // Save the item
        if($this->Item->save($selectedItem)) {

            //This flash message has to be set in the view properly
            $return_message =  "Done.";
        } else {

            //This flash message has to be set in the view properly
            $return_message =  "Sorry an error occurred.";
        }

        // Set the view variables to controller variable values and layout for the view
        $this->set('return_message',$return_message);
        $this -> layout = 'ajax';        
    }





    /*
    // Objective : This function shows the searched item
    // Author : Ishan Sheth
    // Last Edit : 4/8/2014
    */ 
    public function search() {

        // Check whether it is a post request or not
        if ($this -> request -> is('post')) {

            // Get the data from post request
            $item = $this->request->data;
            $search = $item['Item']['search_term'];

            // Check whether search term is null, if yes - redirect to index
            if(empty($search) || $search == "" || $search == null) {

                // Display failure message and redirect
                $this->Session->setFlash('Search item name blank.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'items', 'action' => 'index'));
            }            

            // Find the item
            $finalSearchItems = $this->Item->find('all',array(
                'conditions'=>array("OR" => array('Item.name LIKE'=>'%'.$search.'%','ItemCategory.name LIKE'=>'%'.$search.'%')),
                'order'=>array('Item.item_category_id')
                ));
            $this -> set('items', $finalSearchItems);

            // Set the view variables to controller variable values and layout for the view
            $this -> set('page_title', 'Search Items');
            $this -> layout = 'base_layout';            

        } else {

            // Display failure message and redirect
            $this->Session->setFlash('Invalid page access.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'items', 'action' => 'index'));
        
        }

    }




    /*
    // Objective : This function shows the matching item to be found for autofilling in Add Item
    // Author : Ishan Sheth
    // Last Edit : 4/8/2014
    */ 
    public function find() {

       // Setting the recursive property for Item model to -1 
       $this->Item->recursive = -1;

       // Check whether it is a ajax request or not
       if ($this->request->is('ajax')) {

          // Setting autorender property to false and specifying layout as ajax layout  
          $this->autoRender = false;
          $this->layout = 'ajax';

          // Fetches Item - ID,Name,Alias,Variant Name by searching search term in "name" & "alias" fields
          $results = $this->Item->find('all',
                array('fields' => array('Item.id','Item.name','Item.alias','Item.variant_name'),
                    'conditions' => array('OR' => array(array('Item.name LIKE' => '%'.$this->request->query['term'].'%'), array('Item.alias LIKE' => '%'.$this->request->query['term'].'%')))
                    ));

          // Formatting the result array to match our needs of autocomplete box display
          $final_results = array();
          foreach ($results as $result) {
              $temp = array();  
              $temp['name'] = $result['Item']['name']." ( ".$result['Item']['variant_name']." ) ".$result['Item']['alias'];
              $temp['id'] = $result['Item']['id'];
              array_push($final_results, $temp);
          }

          // Encode the final results array into json
          //$autofill = Set::extract('../Item/name', $results);           
          echo json_encode($final_results);

       }
    }





    /*
    // Objective : This function shows the matching item to be found for parent item in Add Item
    // Author : Ishan Sheth
    // Last Edit : 4/8/2014
    */ 
    public function find_parent() {
       // Setting the recursive property for Item model to -1  
       $this->Item->recursive = -1;

       if ($this->request->is('ajax')) {

          $this->autoRender = false;
          $this->layout = 'ajax';

          $results = $this->Item->find('all',
                array('fields' => array('Item.id','Item.name','Item.alias','Item.variant_name'),
                    'conditions' => array('OR' => array(array('Item.name LIKE' => '%'.$this->request->query['term'].'%'), array('Item.alias LIKE' => '%'.$this->request->query['term'].'%')),'item_id'=> null)
                    ));

          $final_results = array();
          foreach ($results as $result) {
              $temp = array();  
              $temp['name'] = $result['Item']['name']." ( ".$result['Item']['variant_name']." ) ".$result['Item']['alias'];
              $temp['id'] = $result['Item']['id'];
              array_push($final_results, $temp);
          }

          //$autofill = Set::extract('../Item/name', $results);           
          echo json_encode($final_results);

       }
    }   

    /*
    // Objective : This function redirect user to bulk insert using xl.
    // Author : Divyek Soni
    // Last Edit : 17/04/2015
    */   
    public function add_bulk()
    {
        $this->set('page_title','Add Bulk Item');
        $this->layout = 'base_layout';
    }

    /*
    // Objective : This function export uploaded xl file.
    // Author : Divyek Soni
    // Last Edit : 17/04/2015
    */   
    public function export_upload()
    {
        if($this->request->is('post'))
        {
            $file_name = $this->data['BulkItem']['path']['name'];
            move_uploaded_file($this->data['BulkItem']['path']['tmp_name'], TMP.'uploads'.DS.'BulkItem'.DS.$file_name);
            $messages = $this->BulkItem->import($file_name);
            $this->layout = 'base_layout';
            $this->redirect(array('controller' => 'items', 'action' => 'bulk_item'));
        }
    }
        


    public function bulk_item() {

        // get all complete listed items from bulk_item and move to item table and delete from bulk_items table
        //$complte_listed_item = $this->BulkItem->find('all', array('conditions'=>array('not'=>array('item_category_id'=>null, 'price'=>null,'discount_price'=>null,'stock_type'=>null))));        
        $complte_listed_item = $this->BulkItem->find('all');
        
        if ($complte_listed_item) {

            // for store as Item model
            $complte_item = array();
            // for store all id of complete list.
            $complete_list_ids = array();
          
            foreach ($complte_listed_item as $tmp_complte_listed_item) {
                
                $complte_item['Item']['name'] = $tmp_complte_listed_item['BulkItem']['name'];
                if ($tmp_complte_listed_item['BulkItem']['priority'] != null) {
                    $complte_item['Item']['priority'] = $tmp_complte_listed_item['BulkItem']['priority'];
                }
                //$complte_item['Item']['priority'] = $tmp_complte_listed_item['BulkItem']['priority'];
                $complte_item['Item']['item_category_id'] = $tmp_complte_listed_item['BulkItem']['item_category_id'];
                $complte_item['Item']['variant_name'] = $tmp_complte_listed_item['BulkItem']['variant_name'];
                $complte_item['Item']['stock_type'] = $tmp_complte_listed_item['BulkItem']['stock_type'];

                $complte_item['Item']['total_quantity'] = $tmp_complte_listed_item['BulkItem']['total_quantity'];
                $complte_item['Item']['vendor_id'] = $tmp_complte_listed_item['BulkItem']['vendor_id'];                

                $complte_item['Item']['price'] = $tmp_complte_listed_item['BulkItem']['price'];
                // check discount price is less than or equal to price otherwise set same as price.

                if ($tmp_complte_listed_item['BulkItem']['discount_price'] > $tmp_complte_listed_item['BulkItem']['price']) {
                   
                    $complte_item['Item']['discount_price'] = $tmp_complte_listed_item['BulkItem']['price'];
                }
                else {
                     $complte_item['Item']['discount_price'] = $tmp_complte_listed_item['BulkItem']['discount_price'];
                }
                if ($tmp_complte_listed_item['BulkItem']['franchise_only'] != null ) {
                    $complte_item['Item']['franchise_only'] = $tmp_complte_listed_item['BulkItem']['franchise_only'];
                }
                
                if ($tmp_complte_listed_item['BulkItem']['featured'] != null) {
                    $complte_item['Item']['featured'] = $tmp_complte_listed_item['BulkItem']['featured'];
                }
                if ($tmp_complte_listed_item['BulkItem']['item_features'] != null) {
                    $complte_item['Item']['item_features'] = $tmp_complte_listed_item['BulkItem']['item_features'];
                }              
                
                $complte_item['Item']['short_desc'] = $tmp_complte_listed_item['BulkItem']['short_desc'];
                $complte_item['Item']['long_desc'] = $tmp_complte_listed_item['BulkItem']['long_desc'];
                $complte_item['Item']['keyword'] = $tmp_complte_listed_item['BulkItem']['keyword'];
                if ($tmp_complte_listed_item['BulkItem']['item_size'] != null) {
                    $complte_item['Item']['item_size'] = $tmp_complte_listed_item['BulkItem']['item_size'];
                }
                if ($tmp_complte_listed_item['BulkItem']['item_color'] != null) {                
                    $complte_item['Item']['item_color'] = $tmp_complte_listed_item['BulkItem']['item_color'];
                }
            
                // set according to requiremnet for add item in add method
                $complte_item['Item']['item_id']="";
                //$complte_item['Item']['item_category_id']="";
                $complte_item['Item']['shipping_charges']="";
                //$complte_item['Item']['long_desc'] = htmlentities($complte_item['Item']['long_desc']);
                
                // append bulk item id
                
                array_push($complete_list_ids, $tmp_complte_listed_item['BulkItem']['id']);
                /** add records in item table */

                // set all data to $item
                $item = $complte_item;
              
                // Set item sku code
                $item['Item']['sku_code'] = strtoupper("SKU".uniqid());

                // Set null values to null allowed columns and respective preprocessing to data before saving data
                if($item['Item']['item_id']=="") {
                    $item['Item']['item_id'] = null;
                }
                if ($item['Item']['item_category_id']==""){
                    $item['Item']['item_category_id'] = null;
                }
                if ($item['Item']['shipping_charges']=="") {
                    $item['Item']['shipping_charges'] = -1;
                }
                $item['Item']['long_desc'] = htmlentities($item['Item']['long_desc']);
                $discount_percent=0;

                // Processing for items with infinite stock only
                if ($item['Item']['stock_type']==1) {
                  
                    // Check whether item price is not blank
                    if($item['Item']['price']!="") {

                        // If there is no discount price, then set the discounted price to item price
                        if($item['Item']['discount_price']=="") {
                            $item['Item']['discount_price']=$item['Item']['price'];
                        }

                        // Calculate discount percentage, if discounted price is entered
                        $discount_percent = round(($item['Item']['price'] - $item['Item']['discount_price'])/$item['Item']['price'],2)*100;
                    
                    } 
                }
                
                // check if alredy exist in item table
                $item_details = $this->Item->find('all', array("fields"=>array('id', 'name'), 'conditions'=>array('Item.id'=>$tmp_complte_listed_item['BulkItem']['item_id'])));
                
                if (!$item_details) {
                    // Add item
                    $this->Item->create();
                    if ($this->Item ->save($item)) {
                        
                        // Get the last insert id of the item which is inserted
                        $last_id = $this->Item->getInsertID();
                
                        // Processing for items with infinite stock only, add to stock
                        if ($item['Item']['stock_type']==1) {

                            $newStock = array();
                            $newStock['ItemStock']['ref_no'] = "IN000".uniqid();
                            $newStock['ItemStock']['item_id'] = $last_id;
                            $newStock['ItemStock']['total_quantity'] = -1;
                            $newStock['ItemStock']['price'] = $item['Item']['price'];
                            $newStock['ItemStock']['discount_price'] = $item['Item']['discount_price'];
                            $newStock['ItemStock']['discount_percentage'] = $discount_percent;
                            $newStock['ItemStock']['vendor_id'] = "53e9c4b2-6c28-4a73-a8c3-3519bf642048";
                            $this->ItemStock->create();
                            $this->ItemStock->save($newStock);
                            
                        } 
                        elseif ($item['Item']['stock_type']==0) {

                            //$this -> redirect(array('controller' => 'item_stocks', 'action' => 'add',$last_id));
                            $newStock = array();
                            $newStock['ItemStock']['ref_no'] = "IN000".uniqid();
                            $newStock['ItemStock']['item_id'] = $last_id;
                            $newStock['ItemStock']['total_quantity'] = $item['Item']['total_quantity'];
                            $newStock['ItemStock']['price'] = $item['Item']['price'];
                            $newStock['ItemStock']['discount_price'] = $item['Item']['discount_price'];
                            $newStock['ItemStock']['discount_percentage'] = $discount_percent;
                            $newStock['ItemStock']['vendor_id'] = $item['Item']['vendor_id'];
                            $this->ItemStock->create();
                            $this->ItemStock->save($newStock);                      
                          
                        }
                    }
                    else {
                         // Display failure message and redirect
                        $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                        $this -> redirect(array('controller' => 'items', 'action' => 'add_bulk'));
                    }
                }
                else {
                    // set id for update
                    $item['Item']['id'] = $item_details[0]['Item']['id'];

                    // Save item
                    if ($this->Item ->save($item)) {

                        // Get the last insert id of the item which is inserted
                        $last_id = $item['Item']['id'];

                        // Processing for items with infinite stock only, add to stock
                        if ($item['Item']['stock_type']==1){
                            
                            // Find the stock for the item, if present - save the edits or add new item stock
                            $newStock = $this->ItemStock->findByItemId($last_id);
                            if ($newStock == null) {
                                $newStock = array();
                                $newStock['ItemStock']['ref_no'] = "IN000".uniqid();
                                $newStock['ItemStock']['item_id'] = $last_id;
                                $newStock['ItemStock']['total_quantity'] = -1;
                                $newStock['ItemStock']['price'] = $item['Item']['price'];
                                $newStock['ItemStock']['discount_price'] = $item['Item']['discount_price'];
                                $newStock['ItemStock']['discount_percentage'] = $discount_percent;
                            } 
                            else { 
                                $newStock['ItemStock']['price'] = $item['Item']['price'];
                                $newStock['ItemStock']['discount_price'] = $item['Item']['discount_price'];
                                $newStock['ItemStock']['discount_percentage'] = $discount_percent;
                            }
                            $this->ItemStock->save($newStock);
                        }
                        elseif ($item['Item']['stock_type']==0) {
                            // Find the stock for the item, if present - save the edits or add new item stock
                            $newStock = $this->ItemStock->findByItemId($last_id);
                            if($newStock == null) {
                                $newStock = array();
                                $newStock['ItemStock']['ref_no'] = "IN000".uniqid();
                                $newStock['ItemStock']['item_id'] = $last_id;
                                $newStock['ItemStock']['total_quantity'] = $item['Item']['total_quantity'];
                                $newStock['ItemStock']['price'] = $item['Item']['price'];
                                $newStock['ItemStock']['discount_price'] = $item['Item']['discount_price'];
                                $newStock['ItemStock']['discount_percentage'] = $discount_percent;
                            } 
                            else { 
                                $newStock['ItemStock']['price'] = $item['Item']['price'];
                                $newStock['ItemStock']['discount_price'] = $item['Item']['discount_price'];
                                $newStock['ItemStock']['discount_percentage'] = $discount_percent;
                            }
                            $this->ItemStock->save($newStock);
                          
                        }
                    } 
                    else {

                        // Display failure message and redirect
                        $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                        $this -> redirect(array('controller' => 'items', 'action' => 'add_bulk'));
                    }
                }                 
                
            }

            //remove these records from bulk_item table
            foreach ($complete_list_ids as $tmp_complete_list_ids) {
                $this->BulkItem->delete($tmp_complete_list_ids);
            }
           
            // Display failure message and redirect
            $this->Session->setFlash('Successfully imported.', 'default', array('class' => 'alert alert-success') , 'success');
            $this -> redirect(array('controller' => 'items', 'action' => 'index'));

        }
        // we prepare our query, the cakephp way!
        // $this->paginate = array(
        //     'limit' => 10/*,
        //     'order' => array('Item.modified' => 'desc')*/
        // );
     
        // // we are using the 'Item' model
        // $items = $this->paginate('BulkItem');

        // // Set the view variables to controller variable values and layout for the view
        // $this -> set('items', $items);
        // $this -> set('page_title', 'View Bulk Entry Items');
        // $this -> layout = 'base_layout';

        // // total entry of item count
        // $item_count = $this-> BulkItem ->find('all');
        // $item_count1 = sizeof($item_count);
        // $this->set('item_count',$item_count1);
    }

}
?>