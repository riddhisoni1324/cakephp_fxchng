<?php

class CouponsController extends AppController {

	public $name = 'Coupons';
	var $uses = array('Coupon','Item','ItemCategory','City');





    /*
    // Objective : This function displays all the coupons
    // Author : Ishan Sheth
    // Last Edit : 10/8/2014
    */
    public function index(){

        // Find all coupons and push the item/item category details to the array
        $coupons = $this -> Coupon -> find('all',array('order' => array('Coupon.created' => 'desc'))); 
   
        $finalCoupons = array();
        foreach($coupons as $coupon) {
            $itemTemp = array();
            $itemCatTemp = array();

            $itemTemp = $this -> Item -> findById($coupon['Coupon']['item_id']);
            $itemCatTemp = $this -> ItemCategory -> findById($coupon['Coupon']['item_category_id']);

            $coupon['Coupon']['item_id'] =  isset($itemTemp['Item']['name'])? $itemTemp['Item']['name'] : null ;
            $coupon['Coupon']['item_category_id'] = isset($itemCatTemp['ItemCategory']['name'])? $itemCatTemp['ItemCategory']['name'] : null ;

            array_push($finalCoupons, $coupon);
        }

        // Set the view variables to controller variable values and layout for the view
        $this -> set('coupons', $finalCoupons);
        $this -> set('page_title', 'View Coupons');
        $this -> layout = 'base_layout';
    }




    
    /*
    // Objective : This function adds the coupon
    // Author : Ishan Sheth
    // Last Edit : 10/8/2014
    */
    public function add() {
        
        // Check whether it is a post request or not            
        if ($this -> request -> is('post')) {

            // Get the data from post request
            $coupon = $this -> request -> data;

            // Set null values to null allowed columns and respective preprocessing to data before saving data
            if($coupon['Coupon']['item_category_id'] == ""){
                $coupon['Coupon']['item_category_id'] = null;
            }
            if($coupon['Coupon']['item_id'] == ""){
                $coupon['Coupon']['item_id'] = null;
            } 
            if($coupon['Coupon']['percent'] == ""){
                $coupon['Coupon']['percent'] = 0;
            } 
            if($coupon['Coupon']['value'] == ""){
                $coupon['Coupon']['value'] = 0;
            }  
            if($coupon['Coupon']['max_count'] == ""){
                $coupon['Coupon']['max_count'] = 0;
            }  
            if($coupon['Coupon']['max_value'] == ""){
                $coupon['Coupon']['max_value'] = 0;
            }                                    

            // Add coupon
            if ($this -> Coupon -> save($coupon)) {

                // Display success message and redirect
                $this-> Session ->setFlash('Coupon added.', 'default', array('class' => 'alert alert-success') , 'success');
                $this -> redirect(array('controller' => 'coupons', 'action' => 'index'));
            } else {

                // Display failure message and redirect
                $this-> Session ->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'coupons', 'action' => 'index'));
            }              

        } else {

            // Set the items
            $itemsList = array();
            $this -> set('items', $itemsList);        

            // Set the item categories
            $itemCats = $this -> ItemCategory -> find('list', array('order' => 'ItemCategory.name ASC'));
            $this -> set('item_categories', $itemCats);        

            // Set the type of coupon options here
            $couponType = array(0=>'Percent', 1=>'Value');
            $this -> set('coupon_type', $couponType);            

            // Set the view variables to controller variable values and layout for the view
            $this -> set('page_title', 'Add Coupon');
            $this -> layout = 'base_layout';  
        }            

    }




    
    /*
    // Objective : This function saves the edited coupon
    // Author : Ishan Sheth
    // Last Edit : 25/4/2014
    */
    /*public function edit($id=null) {

        // Check whether it is a post request or not
        if($this -> request -> is('post') ) {

            // Get the data from post request
            $coupon = $this -> request -> data;
            pr($coupon);

            // Set null values to null allowed columns and respective preprocessing to data before saving data
            if(!isset($coupon['Coupon']['shipping_free'])) {
                $coupon['Coupon']['shipping_free'] = 0;
            }
            if(!isset($coupon['Coupon']['active'])) {
                $coupon['Coupon']['active'] = 0;
            }
            if(!isset($coupon['Coupon']['item_category_id'])) {
                $coupon['Coupon']['item_category_id'] = "";
            }            

            // Save coupon
            if ($this -> Coupon -> save($coupon)) {     
                
                // Display success message and redirect
                $this->Session->setFlash('Selected Coupon edited.', 'default', array('class' => 'alert alert-success') , 'success');
                $this -> redirect(array('controller' => 'Coupons', 'action' => 'index'));

            } else {
                
                // Display failure message and redirect
                $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'Coupons', 'action' => 'index'));
            }

        } else {

            // Check whether ID is null, if yes - redirect to index
            if($id == null){
                $this->Session->setFlash('Please choose a coupon.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'coupons', 'action' => 'index'));
            }

            // Fetch the item category by id
            $selectedCoupon = $this->Coupon->findById($id);

            // Check whether resultset is null, if yes - redirect to index
            if($selectedCoupon == null){
                $this->Session->setFlash('Please choose a coupon.', 'default', array('class' => 'alert alert-danger') , 'error');
                $this -> redirect(array('controller' => 'coupons', 'action' => 'index'));
            }

            // Fetch the item category by id
            $item = $this->Item->findById($selectedCoupon['Coupon']['item_id']);

            // Set the items
            $itemsList = array();
            $this -> set('items', $itemsList);          

            // Set the item categories
            $itemCats = $this -> ItemCategory -> find('list', array('order' => 'ItemCategory.name ASC'));
            $this -> set('item_categories', $itemCats); 

            // Set the type of coupon options here
            $couponType = array(0=>'Percent', 1=>'Value');
            $this -> set('coupon_type', $couponType);

            // Set the view variables to controller variable values and layout for the view
            $this->set('coupon',$selectedCoupon);
            $this->set('item',$item);
            $this -> set('page_title', 'Edit Coupon');
            $this -> layout = 'base_layout';
        }

    }*/





    /*
    // Objective : This function deletes the selected coupon
    // Author : Ishan Sheth
    // Last Edit : 25/4/2014
    */  
    public function delete($id=null) {

        // Check whether ID is null, if yes - set error message and redirect
        if($id == null) {
            $this->Session->setFlash('Please choose a coupon.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'coupons', 'action' => 'index'));
        }

        // Find the selected item
        $selectedCoupon = $this->Coupon->findById($id);

        // Check whether resultset is null, if yes - set error message and redirect
        if($selectedCoupon == null){
            $this->Session->setFlash('Please choose a coupon.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'items', 'action' => 'index'));
        }

        // Delete coupon
        if($this->Coupon->delete($selectedCoupon['Coupon']['id'])){

            // Display success message and redirect
            $this->Session->setFlash('Coupon deleted.', 'default', array('class' => 'alert alert-success') , 'success');
            $this -> redirect(array('controller' => 'coupons', 'action' => 'index'));
        
        } else {

            // Display failure message and redirect
            $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'items', 'action' => 'index'));
        }
    }





    /*
    // Objective : This function sets the selected coupon's active flag
    // Author : Ishan Sheth
    // Last Edit : 23/4/2014
    */ 
    public function set_active($id=null) {

        // Check whether ID is null, if yes - set error message and redirect
        if($id == null){
            $this->Session->setFlash('Please choose a coupon.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'coupons', 'action' => 'index'));
        }

        // Find the selected coupon
        $selectedCoupon = $this->Coupon->findById($id);

        // Check whether resultset is null, if yes - set error message and redirect
        if($selectedCoupon == null){
            $this->Session->setFlash('Please choose a coupon.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'items', 'action' => 'index'));
        }

        // Set the active flag to true
        $selectedCoupon['Coupon']['active']=1;

        // Save the coupon
        if($this->Coupon->save($selectedCoupon)){

            // Display success message and redirect
            $this->Session->setFlash('Coupon set to active.', 'default', array('class' => 'alert alert-success') , 'success');
            $this -> redirect(array('controller' => 'coupons', 'action' => 'index'));

        } else {

            // Display failure message and redirect
            $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'items', 'action' => 'index'));
        }
        
    }





    /*
    // Objective : This function unsets the selected coupon's active flag
    // Author : Ishan Sheth
    // Last Edit : 23/4/2014
    */ 
    public function set_inactive($id=null) {

        // Check whether ID is null, if yes - set error message and redirect
        if($id == null){
            $this->Session->setFlash('Please choose a coupon.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'coupons', 'action' => 'index'));
        }

        // Find the selected coupon
        $selectedCoupon = $this->Coupon->findById($id);

        // Check whether resultset is null, if yes - set error message and redirect
        if($selectedCoupon == null) {
            $this->Session->setFlash('Please choose a coupon.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'items', 'action' => 'index'));
        }

        // Set the featured flag to false
        $selectedCoupon['Coupon']['active']=0;

        // Save the item
        if($this->Coupon->save($selectedCoupon)){

            // Display success message and redirect
            $this->Session->setFlash('Coupon set to inactive.', 'default', array('class' => 'alert alert-success') , 'success');
            $this -> redirect(array('controller' => 'coupons', 'action' => 'index'));
        
        } else {

            // Display failure message and redirect
            $this->Session->setFlash('Sorry, an error occurred.', 'default', array('class' => 'alert alert-danger') , 'error');
            $this -> redirect(array('controller' => 'items', 'action' => 'index'));
        }        
    }            
	
}
?>